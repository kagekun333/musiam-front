import machineObservations from '../data/music-machine-observations.json';
import audioClaims from "../../public/works/audio-source-claims.json";
import { dedupeWorks } from "./dedupeWorks";
import { getPublicLinksForCard } from "./work-links";
import { rankSemanticWorks, workSemanticProfile } from "./work-semantic-profile";
import type { CatalogWork } from "./mergeWorksCatalog";
import {linkedCatalogMetadata} from './count-catalog-lineage';
import editorialKnowledge from "../../public/works/editorial-knowledge.json";
import { explicitCatalogConstraints, satisfiesCatalogConstraints, matchedCatalogConstraintLabels } from "./count-catalog-constraints";

type Message = {role:string;content:string};
type WorkType = "music" | "book" | "image";
const norm = (s:string) => s.normalize("NFKC").toLowerCase().replace(/[\s「」『』“”"']/g,"");
const kind = (q:string):WorkType|null => {
  const mentions = [...q.matchAll(/写真|画像|空撮|ドローン|音楽|楽曲|曲|本|書籍|music|songs?|tracks?|books?|photos?|images?/gi)]
    .filter(m=>! /^(?:は|が|を)?(?:じゃなく|ではなく|以外|じゃない|ではない)/.test(q.slice((m.index??0)+m[0].length)));
  const word=mentions.at(-1)?.[0]??"";
  return /写真|画像|空撮|ドローン|photo|image/i.test(word)?"image":/本|書籍|book/i.test(word)?"book":/音楽|楽曲|曲|music|song|track/i.test(word)?"music":null;
};
export function catalogEvidence(work:CatalogWork) {
  const audio=audioClaims.items.find(x=>x.workId===String(work.id)&&x.title===work.title);
  if(audio)return {description:audio.description,basis:"local_audio_machine_scoped",source:audio.sourceHref};
  const machine=machineObservations.items.find(x=>x.workId===String(work.id)&&x.title===work.title);
  if(machine)return {description:machine.description,basis:"local_audio_machine_scoped",source:machine.sourceHref};
  const editorial=editorialKnowledge.items.find(e=>e.workId===String(work.id)&&e.title===work.title);
  if(editorial&&!work.contentEvidence)return {description:editorial.summaryJa,basis:"public_editorial",source:editorial.sourceHref};
  const inferred=work.tags?.some(t=>/inferred|title-only/.test(t))
    || /inferred|推定|タイトル.*推測/i.test(typeof work.matchInfo==="object"?work.matchInfo.reason??"":"");
  const raw = work.contentEvidence?.description ?? (inferred ? "" : [
    typeof work.matchInfo==="string"?work.matchInfo:work.matchInfo?.summary,
    ...(work.ssd?.tracks??[]).map(t=>t.notes?.split("MV映像イメージ:")[0]),
  ].filter(Boolean).join(" "));
  const linked=!raw.trim()&&!inferred&&!work.contentEvidence?linkedCatalogMetadata(work):null;
  if(linked)return {description:linked.description,basis:'metadata_only',source:linked.source};
  return {description:raw.trim(),basis:work.contentEvidence?"content_derived":inferred?"inferred_not_used":raw?"metadata_only":"unknown",source:work.contentEvidence?.source??(inferred?"inferred_notes":"registered_metadata")};
}

export function vocalEvidenceFor(work:CatalogWork) {
  const description=work.contentEvidence?.description??"";
  // Descriptive/inferred notes are not an audio review. A preview cannot prove
  // absence of vocals throughout the whole recording either.
  const wholeRecording=Boolean(work.contentEvidence?.assetSha256)
    && /(?:full[-_ ]?(?:audio|track|recording)|whole[-_ ]?recording|全曲音声|全編音声)/i.test(work.contentEvidence?.source??"");
  const noVocals=/(?:歌声|歌詞|ボーカル|声)(?:は|が)?(?:なし|ない)|インストゥルメンタル|instrumental|without vocals|no vocals/i.test(description);
  const vocals=/(?:歌声|歌詞|ボーカル|vocal)/i.test(description.replace(/(?:歌声|歌詞|ボーカル|声)(?:は|が)?(?:なし|ない)|without vocals|no vocals/gi,""));
  return {status:wholeRecording?(vocals?"confirmed_vocals":noVocals?"confirmed_no_vocals":"unknown"):"unknown",source:work.contentEvidence?.source??null,metadataClaimsInstrumental:workSemanticProfile(work).instrumentalExplicitlyTagged};
}

export function parseRecommendationConstraints(messages:Message[]) {
  const users=messages.filter(m=>m.role==="user").map(m=>m.content);
  let type:WorkType|null=null, noVocals=false;
  for(const q of users){
    type=kind(q)??type;
    if(/(?:歌声|歌詞|ボーカル|歌|声)(?:は|が|を)?(?:いらない|要らない|なし|不要)|without (?:vocals|lyrics)|no (?:vocals|singing)|instrumental(?: only)?/i.test(q)) noVocals=true;
    if(/(?:歌声|歌詞|ボーカル|歌)(?:は|が|も)?(?:あって|ありで|入りで|あっても)|vocals? (?:are |is )?(?:fine|okay|ok)|with vocals/i.test(q)) noVocals=false;
  }
  return {type,noVocals,explicit:explicitCatalogConstraints(users),query:users.slice(-6).join("\n"),latest:users.at(-1)??""};
}

function cardFor(work:CatalogWork,reason:string) {
  const links=getPublicLinksForCard(work).map(l=>({kind:/spotify|appleMusic|amazonMusic/.test(l.kind)?"listen":l.kind,url:l.url}));
  if(!work.id||!work.title||!links.length||work.catalogStatus?.identityConflict||work.catalogStatus?.recommendationEligible===false)return null;
  return {id:String(work.id),title:work.title,type:work.type,cover:work.cover||"/brand/catalog-placeholder.svg",links,moodTags:(work.moodTags??[]).slice(0,4),reason};
}
function reference(works:CatalogWork[],q:string) {
  const text=q.normalize("NFKC").toLowerCase();
  return works.filter(w=>{
    if(!w.title||norm(w.title).length<3)return false;
    const title=w.title.normalize("NFKC").toLowerCase();
    if(/[\u3040-\u30ff\u3400-\u9fff]/.test(title))return norm(text).includes(norm(title));
    const escaped=title.replace(/[.*+?^${}()|[\]\\]/g,"\\$&").replace(/\s+/g,"\\s+");
    return new RegExp(`(?<![\\p{Script=Latin}\\p{N}])${escaped}(?![\\p{Script=Latin}\\p{N}])`,"u").test(text);
  })
    .sort((a,b)=>norm(b.title!).length-norm(a.title!).length)[0];
}
export function buildCatalogConversation(worksInput:CatalogWork[],messages:Message[],lang:string,commercialStopped=false) {
  const works=dedupeWorks(worksInput), q=messages.filter(m=>m.role==="user").at(-1)?.content??"";
  const ja=lang==="ja", previous=[...messages].reverse().find(m=>m.role==="assistant")?.content??"";
  const hideLinks=commercialStopped||/(?:価格|リンク|ボタン|販売|問い合わせ|予約)(?:・[^。]+)?(?:は|の導線は|への導線は)?(?:不要|出さない)|no (?:links|buttons|checkout)|without (?:links|buttons|checkout)|sin.{0,55}(?:enlaces|compra)/i.test(q);
  if(/catalog|catálogo|カタログ/i.test(q)&&/(?:other|another) language|otro idioma|別の言語|多言語/i.test(q)&&/edition|edición|版/i.test(q)){
    const editions=works.filter(w=>/\((?:English|German|French|Spanish) Edition\)/i.test(w.title??""));
    const samples=editions.slice(0,2).map(w=>`“${w.title}”`).join("; ");
    return {text:ja?`別言語の版を明記した書籍が${editions.length}件あります。例は${samples}です。これは登録された版表示の確認で、本文や翻訳品質の確認ではありません。`:`The catalog documents ${editions.length} books with an explicitly labeled language edition, including ${samples}. This verifies registered edition labels, not a review of the text or translation quality.`,card:null,cards:[],cta:null,knowledgeRoute:"catalog_languages",workKnowledge:null,recommendationTrace:null};
  }
  if(/(?:price|価格|定価|値段)/i.test(q)&&/(?:catalog|カタログ|登録)/i.test(q))return {text:ja?"対象作品の確認済みの定価は、このカタログ情報では未確認です。":"The listed price is unknown from the available catalog information for this request.",card:null,cards:[],cta:null,knowledgeRoute:"catalog_price_unknown",workKnowledge:null,recommendationTrace:null};
  const listing=/(?:全作品|全曲|館全体|作品一覧|カタログ全体|一覧が|全体像|all (?:the )?works|whole catalog|catalog(?:ue)? overview|list (?:all|the works))/i.test(q);
  if(listing){
    const counts=Object.fromEntries(["music","book","image"].map(t=>[t,works.filter(w=>w.type===t).length]));
    const wantsList=/(?:一覧|全件|全部.{0,8}(?:並べ|列挙)|list|every title)/i.test(q);
    const text=ja
      ? `今の公開カタログは${works.length}作品で、音楽${counts.music}、書籍${counts.book}、写真${counts.image}です。${wantsList?"一覧は「全作品を見る」から開けます。音楽・本・写真を切り替えながら、作品ごとのページや体験先をたどれます。":"音楽は多ジャンル、本はSF・ファンタジー・風刺や古典の翻案、写真は空撮作品が入口になります。まず媒体で眺める、気分や用途から一作を探す、気になった作品から広げる、という巡り方ができます。"}`
      : `The public catalog currently has ${works.length} works: ${counts.music} music releases, ${counts.book} books and ${counts.image} photographs. ${wantsList?"Open the complete catalog below to browse the entries and their individual pages.":"You can explore different musical genres, books including SF, fantasy and adaptations of classics, and aerial photographs. Browse by medium or start with a mood or use."}`;
    return {text,card:null,cards:[],cta:hideLinks?null:{href:"/works",label:ja?"全作品を見る":"Browse all works",productId:"catalog"},knowledgeRoute:"catalog_overview",catalogCounts:counts,workKnowledge:null,recommendationTrace:null};
  }
  const named=reference(works,q);
  const correction=/(?:別の|ほかの|他の|違う|もっと|ではなく|じゃなく|なぜ|どうして|why|another|different|instead|quieter|louder)/i.test(q);
  const previousWork=reference(works,previous);
  const asksSelection=/(?:おすすめ|推薦|選んで|紹介して|聴きたい|聞きたい|読みたい|探して|見たい|見てみたい|見せて|示して|一曲|一冊|一枚|identify|recommend|suggest|choose|pick|want (?:an? |some |to (?:listen|read)))/i.test(q);
  // Explicit creator, commission, shopping, and casual dialogue have their own routes.
  const commission=/(?:依頼|作って|制作して|オーダー|商用|ライセンス|店舗用|店の顔|commission|license|custom song)/i.test(q);
  if(commission)return null;
  const why=correction&&/(?:なぜ|どうして|理由|why)/i.test(q);
  const different=/(?:別の|ほかの|他の|違う|another|different)/i.test(q);
  const asksDetails=/(?:その|この|今の|さっき|that|this|the work)/i.test(q)&&/(?:背景|内容|教えて|知りたい|解説|about|background|describe)/i.test(q);
  if(named&&!asksSelection || previousWork&&(why||asksDetails)&&!different){
    const w=named??previousWork!; const e=catalogEvidence(w);
    const unknownPlot=/(?:主人公|結末|最後|ストーリー|筋書|plot|protagonist|ending)/i.test(q)&&w.type==="book"&&e.basis!=="content_derived";
    const unknownSound=/(?:どんな音|楽器|歌声|歌詞|テンポ|BPM|instrument|vocals?|lyrics)/i.test(q)&&w.type==="music"&&e.basis!=="content_derived";
    const label=w.type==="music"?(ja?"音楽作品":"music release"):w.type==="book"?(ja?"書籍":"book"):(ja?"写真作品":"photograph");
    const details=unknownPlot ? (ja?"本文を確認できていないため、主人公や結末は分かりません。タイトルから物語を補うことはしません。":"I do not have the text needed to verify the protagonist or ending, and will not infer a plot from the title.")
      : e.description ? (ja?`${e.basis==="content_derived"?"素材を確認した記録":e.basis==="public_editorial"?"公式の紹介文":"登録解説"}では、${e.description.slice(0,440)}${e.basis!=="content_derived"?" これは登録資料の説明で、私が実音源・本文を確認したという意味ではありません。":""}`:`${e.basis==="content_derived"?"The reviewed asset description":e.basis==="public_editorial"?"The official editorial introduction":"The registered description"} says: ${e.description.slice(0,440)}${e.basis!=="content_derived"?" This is metadata, not an independent review of the audio or full text.":""}`)
      : ja?"内容を裏づける資料がまだなく、タイトルから音や筋書き、特徴を推測することはできません。":"I do not yet have evidence for its content and cannot infer sound, plot or characteristics from its title.";
    const reason=why?(ja?"前の提案は登録情報を手がかりにした候補です。実際の好みに合うかは体験して判断してください。":"The earlier suggestion was based on registered information; its actual fit needs your judgment."):"";
    const text=ja?`「${w.title}」は${label}です。${details}${unknownSound?" 歌声・楽器の確定には音源の確認が必要です。":""}${reason}`:`“${w.title}” is a ${label}. ${details} ${reason}`;
    const card=hideLinks?null:cardFor(w,ja?"指定された作品の確認用":"The work you asked about");
    return {text,card,cards:card?[card]:[],cta:null,knowledgeRoute:"work_facts",workKnowledge:{title:w.title,workId:String(w.id),matchKind:"catalog-title",evidenceBasis:e.basis,evidenceSource:e.source},recommendationTrace:null};
  }
  const previousSelection=Boolean(previousWork)||/(?:作品|一作|一曲|登録情報|条件|work|track|recommend)/i.test(previous);
  if(!asksSelection&&!(correction&&previousSelection))return null;
  const constraints=parseRecommendationConstraints(messages);
  // Avoid turning an unqualified "recommend something" into a forced type.
  if(!constraints.type&&previousWork&&["music","book","image"].includes(previousWork.type??""))constraints.type=previousWork.type as WorkType;
  if(!constraints.type)return null;
  const seen=works.filter(w=>w.title&&messages.filter(m=>m.role==="assistant").some(m=>norm(m.content).includes(norm(w.title!)))).map(w=>String(w.id));
  const changed=/(?:別の|ほかの|他の|違う|another|different)/i.test(q);
  const eligible=works.filter(w=>w.type===constraints.type&&!w.catalogStatus?.identityConflict&&w.catalogStatus?.recommendationEligible!==false&&(!changed||!seen.includes(String(w.id))));
  const constraintEvidence=(w:CatalogWork)=>{
    const e=catalogEvidence(w);
    if(e.basis==="inferred_not_used")return "";
    const editorial=editorialKnowledge.items.find(x=>x.workId===String(w.id)&&x.title===w.title);
    const edition=w.title?.match(/\((?:English|German|French|Spanish|Japanese) Edition\)/i)?.[0]??"";
    return [e.description,...editorial?.facets??[],...w.tags??[],...w.moodTags??[],...w.moodSeeds??[],edition].join(" ");
  };
  const evidencePool=eligible.filter(w=>(!/public editorial|公式(?:の)?紹介文/i.test(q)||catalogEvidence(w).basis==="public_editorial")&&satisfiesCatalogConstraints(constraintEvidence(w),constraints.explicit)&&(!constraints.noVocals||vocalEvidenceFor(w).status==="confirmed_no_vocals"));
  // Negation has already been resolved in chronological order. Do not let an
  // older no-vocals sentence silently reapply after the guest relaxes it.
  const rankingQuery=constraints.query.replace(/(?:歌声|歌詞|ボーカル|歌|声)(?:は|が|を)?(?:いらない|要らない|なし|不要)|without (?:vocals|lyrics)|no (?:vocals|singing)|instrumental(?: only)?/gi,"");
  const ranked=rankSemanticWorks(evidencePool.map(w=>catalogEvidence(w).basis==="inferred_not_used"?{...w,matchInfo:undefined,ssd:undefined,moodTags:[],moodSeeds:[]}:w),rankingQuery);
  const chosen=ranked[0];
  const trace={requestedType:constraints.type,noVocals:constraints.noVocals,explicitConditions:constraints.explicit,excludedWorkIds:changed?seen:[],candidateCountBeforeConstraints:eligible.length,candidateCountAfterConstraints:evidencePool.length,candidates:ranked.slice(0,5).map(r=>({id:String(r.work.id),score:r.score,matchedFacets:r.matchedFacets,evidenceBasis:catalogEvidence(r.work).basis})),selectedWorkId:chosen?String(chosen.work.id):null,evidenceSource:chosen?catalogEvidence(chosen.work).source:null,failureClass:chosen?null:constraints.noVocals?"CATALOG_EVIDENCE_GAP":"CATALOG_MISS"};
  if(!chosen){
    const repeated=/(?:全編に歌声がない|音源の裏づけ|no vocals throughout|entire recording without vocals)/i.test(previous);
    const text=ja?(why&&constraints.noVocals?"今回は、条件に合うと確認できた一作をまだ選べていません。理由は「歌声なし」を裏づける全編の音源確認がないためです。制作メモのインスト表記を、実際に確認した音の特徴として扱わないようにしています。":constraints.noVocals?repeated?"別の曲でも「歌声なし」という条件は保ちます。ただ、制作メモしかなく確証が足りません。確認できた曲としては、まだお渡しできません。":"「歌声なし」は大切な条件として残しています。ただ、全編に歌声がないと音源から確認できた候補は、今のカタログ資料にはありません。制作メモのインスト表記だけでは断定できません。":"その条件を裏づけられる別作品を、今の資料からは選べませんでした。条件のどこを緩められるかが分かれば、そこから探し直せます。"):(why&&constraints.noVocals?"I have not selected a verified match yet. The missing evidence is a review confirming no vocals throughout the recording; an instrumental label in a production note is not that verification.":constraints.noVocals?repeated?"I understand: a music track with no singing. I still lack full-recording evidence for a replacement, so I cannot supply a verified match yet.":"I have kept your no-vocals requirement. The available evidence does not verify an entire recording without vocals, so I cannot honestly select a track on that basis.":"I could not find another work supported by these conditions.");
    return {text,card:null,cards:[],cta:null,knowledgeRoute:"recommendation_no_match",workKnowledge:null,recommendationTrace:trace};
  }
  const facets=[...matchedCatalogConstraintLabels(constraintEvidence(chosen.work),constraints.explicit),...chosen.matchedFacets].slice(0,3); const evidence=catalogEvidence(chosen.work);
  const reason=ja?(facets.length?`ご希望と登録情報の${facets.map(f=>`「${f}」`).join("・")}が重なるためです。${evidence.basis==="content_derived"?"内容を確認した記録にも基づきます。":evidence.basis==="public_editorial"?`公式紹介では、${evidence.description} 本文を独立に読んだという意味ではありません。`:"登録メタデータを手がかりにした候補で、実音源・本文の確認はまだです。"}`:"条件に合うと断言できる材料は少ないため、カタログを眺める入口としての候補です。"):(facets.length?`Its registered attributes overlap with your request: ${facets.join(", ")}. This is a metadata-based suggestion, not proof of personal fit.`:"This is a starting point; there is not enough evidence to claim a precise fit.");
  const card=cardFor(chosen.work,reason);
  if(!card)return {text:ja?"候補は見つかりましたが、今ご案内できる体験先を確認できませんでした。":"A candidate exists, but I cannot verify a usable destination for its card.",card:null,cards:[],cta:null,knowledgeRoute:"recommendation_no_link",workKnowledge:null,recommendationTrace:{...trace,selectedWorkId:null,failureClass:"AVAILABILITY_GAP"}};
  const factual=/私向けの推薦ではなく|明記|確認済みの説明|public editorial|catalog question|factual|identify|事実/i.test(q);
  const rawIntro=evidence.description.replace(/^レターは、/,"");
  const intro=rawIntro&&!/[。.!！?？]$/.test(rawIntro)?rawIntro+(chosen.work.type==="image"?"を写した写真です。":"。"):rawIntro;
  const text=factual?(ja?`登録資料で確認できる一作は「${card.title}」です。${intro?`紹介文では、${intro}`:"特徴を裏づける解説はまだありません。"}${evidence.basis==="public_editorial"?"本文全体の確認ではありません。":""}`:`One documented title is “${card.title}”. Its ${evidence.basis==="public_editorial"?"official editorial introduction":"registered description"} supports the stated catalog condition; this is not a claim of full-text knowledge or personal fit.`):(ja?`「${card.title}」を一つの候補に挙げます。${reason}`:`One candidate is “${card.title}”. ${reason}`);
  const suppressCard=hideLinks||factual;
  return {text:text+(suppressCard?"":ja?" 下の作品カードで確かめられます。":" You can explore it through the card below."),card:suppressCard?null:card,cards:suppressCard?[]:[card],cta:null,knowledgeRoute:"recommendation",workKnowledge:null,recommendationTrace:trace};
}
