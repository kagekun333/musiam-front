# QUESTIONS
- Q1 (Yes/No): Exhibition の Featured は自動再生を許可しますか？  
  推奨: Yes（無音/短尺に限定）  
  根拠: TTW≤10秒の達成

- Q2 (Yes/No): /oracle の“理由一言”はタグ一致/新着/weightのいずれか表示で良いですか？  
  推奨: Yes  
  根拠: 可視化で納得感↑

- Q3 (Yes/No): /count-abi は当面 LLM 不使用（ルールベースAPI）のままでよいですか？  
  推奨: Yes  
  根拠: コスト最小＋安定
