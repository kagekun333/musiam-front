import canonical from "../data/abi-public-canonical.json";
/** Generated public projection only. Private canonical data never enters runtime. */
export const ABI_PUBLIC_KNOWLEDGE = canonical;

type Message = {role: string; content: string};
export type AbiSelfTopic = "overview" | "host" | "practice" | "music" | "books" | "purpose" | "philosophy" | "representative" | "recent" | "biography" | "vr";
const normalized = (s: string) => s.normalize("NFKC").trim();
const actor = /(?:\bABI(?:\s*(?:伯爵|hakusyaku)|\b)|伯爵|館主|作り手|作者|本人|同じ館|この(?:サイト|館|場所)|ここの|作った人|運営(?:者|している人)|MUSIAM|ミュージアム|あなた|the (?:count|creator|artist|person behind)|behind (?:this|the) (?:place|site|museum)|who are you|your (?:work|music|books|practice)|who (?:runs|made|created)|qui (?:êtes|es|a créé|parle|répond)|l['’]artiste|présence numérique|quién (?:eres|es|habla|responde)|wer (?:bist|ist|spricht|antwortet))/i;
const about = /(?:について|教え|知り|誰|だれ|何者|どんな(?:人|方)|紹介|何を|なにを|活動|作って|手がけ|経歴|プロフィール|思想|考え|理由|なぜ|どうして|代表|最近|本名|生年|受賞|about|who|what|why|tell me|describe|biograph|philosoph|creat|\bmake\b|releas|behind|qui|quién|wer)/i;
const topicOnly = /^(?:(?:では|じゃあ|それと|ところで|あと)[、,\s]*)?(?:何者|どなた|どんな人|何を(?:作|つく)|なにを(?:作|つく)|どんな(?:音楽|曲|本)|代表作|本名|生年月日|受賞歴|創作思想|最近何|なぜMUSIAM|VR)/i;

/** Actor + information intent + conversational reference, rather than a list of exact questions. */
export function classifyAbiSelfQuery(messages: Message[]): AbiSelfTopic | null {
  const q = normalized(messages.filter(m => m.role === "user").at(-1)?.content ?? "");
  const previous = messages.slice(0,-1).slice(-12).map(m=>m.content).join("\n");
  if (/(?:全作品|作品一覧|館全体|all (?:the )?works|catalog(?:ue)? overview)/i.test(q)) return null;
  const signature=/(?:代表作|代表作品|いちばん有名|一番有名|signature|representative|best.known)/i.test(q);
  if(signature&&(actor.test(q)||actor.test(previous)||/(?:本|曲|作品|work|book)/i.test(q)))return "representative";
  const creation=/(?:作[っるり]|つく[っるり]|書い|書く|手がけ|制作|創作|生成|分担|協働|make|creat|writ|releas)/i.test(q);
  const aiPractice=/(?:AI|人工知能)/i.test(q)&&creation&&/(?:人|自動|だけ|分担|役割|使|どう|solely|only|human|role)/i.test(q);
  if(aiPractice)return "philosophy";
  // A named work or an explicit request to select one remains catalog intent.
  if (/[「『][^」』]+[」』]/.test(q) || /(?:おすすめ|推薦|選んで|一曲|一冊|一枚|(?:本|写真|曲|作品).{0,12}紹介して|recommend|show me|pick a|choose a)/i.test(q)) return null;
  if(actor.test(previous)&&/(?:本|書籍|books?).{0,35}(?:どんな|種類|ジャンル|世界|what kind|genre)/i.test(q))return "books";
  const self = (actor.test(q) && about.test(q)) || topicOnly.test(q)
    || (creation&&actor.test(previous)&&!/(?:作って(?:ほしい|ください)|書いて(?:ほしい|ください)|write me|make me|commission)/i.test(q))
    || (actor.test(previous) && /^(?:それは|その人|本人|では|じゃあ|音楽以外|and what|what else)/i.test(q));
  if (!self) return null;
  if (/(?:本名|生年月日|誕生日|出身|住所|家族|学歴|経歴|受賞|real name|birth|award|family|address|biography)/i.test(q)) return "biography";
  if (/(?:代表作|代表作品|一番有名|signature|representative|best.known)/i.test(q)) return "representative";
  if (/(?:最近|いま何|今何|現在.*活動|latest|recent|currently)/i.test(q)) return "recent";
  if (/\bVR\b|仮想現実/i.test(q)) return /(?:音楽|書籍|写真|映像|music|books?|photos?|videos?)/i.test(q)?"practice":"vr";
  if (/(?:なぜ|どうして|理由|作った目的|why)/i.test(q)) return "purpose";
  if (/(?:思想|哲学|信念|philosoph|belie|AI.*(?:使|利用)|AI.*partner)/i.test(q)) return "philosophy";
  if (/(?:音楽以外|何を|なにを|活動|手がけ|what.*(?:make|create|work)|what else|do you make)/i.test(q)) return "practice";
  if (/(?:どんな本|本も|書籍|書いて|books|writ)/i.test(q)) return "books";
  if (/(?:どんな音楽|どんな曲|music|genre)/i.test(q)) return "music";
  if (/(?:あなたは誰|あなたって|君は|AIなの|人間なの|who are you|are you.*(?:person|human|AI)|qui (?:êtes|parle|répond)|quién (?:eres|habla|responde)|wer (?:bist|spricht|antwortet))/i.test(q)) return "host";
  return "overview";
}


/** Disclosure is resolved from the current query, never a past sensitive question. */
export function visibleAbiFacts(query = "") {
  const identity = /本名|実名|通称|Kagemichi|Abiko|real name|legal name|stage name|pen name|pseudonym|alias|nom réel|nom de scène|pseudonyme|bürgerlich|Künstlername|nombre real|nombre artístico|芸名|筆名|名義|اسم مستعار/i.test(query);
  const cannabis = /大麻|合法化|cannabis|hemp|麻|legalization/i.test(query);
  const interests = /関心|趣味|interests?|hobb/i.test(query);
  return canonical.facts.filter(f => f.disclosure !== "explicit_identity" || identity)
    .filter(f => !["legalization-reflection","wishes","interests"].includes(f.id) || cannabis || interests);
}

export function abiKnowledgeReply(topic: AbiSelfTopic, lang: string, query = "") {
  const ids: Record<AbiSelfTopic,string[]> = {
    overview:["practice","curiosity","experience"], host:["host","creation-tools-vs-guide"],
    practice:["practice","creative-strength"], music:["music-range","creative-strength"],
    books:["book-range"], purpose:["curiosity","experience"],
    philosophy:/AI|人工知能|partner|パートナー/i.test(query)?["ai-partner"]:["curiosity","pantheism"],
    representative:["representative-selection"], recent:["current-favorites"],
    biography:/本名|実名|通称|Kagemichi|Abiko|real name|legal name|stage name|pen name|pseudonym|alias|nom réel|nom de scène|pseudonyme|bürgerlich|Künstlername|nombre real|nombre artístico|芸名|筆名|名義|اسم مستعار/i.test(query)?["name-relationship"]:["creator"],
    vr:["vr-projects"],
  };
  if (/大麻|合法化|cannabis|legalization/i.test(query)) ids[topic]=["legalization-reflection","wishes"];
  if (/関心|趣味|interests?|hobb/i.test(query)) ids[topic]=["interests"];
  if (/目標|野望|資産|wealth|net worth|ambition|goal|vision|構想/i.test(query)) ids[topic]=/曲|song|music/i.test(query)?["song-ambition"]:["public-social-ambition","wider-vision"];
  const selected=visibleAbiFacts(query).filter(f=>ids[topic].includes(f.id));
  const unknownBiography=/生年|誕生|出生|出身|受賞|学歴|住所|今どこ|birth|award|school|address|where.*now/i.test(query);
  let text=selected.map(f=>lang==="ja"?f.text:f.en??f.text).join("\n");
  if(unknownBiography)text=(lang==="ja"?"生年月日・出生地・学歴・受賞歴・現在地は、確認済みの情報にありません。":"Date of birth, birthplace, education, awards and current location are not established in the verified information.")+"\n"+text;
  return {text,topic,factIds:selected.map(f=>f.id),unknown:unknownBiography?["biography-details"]:[],sourceVersion:canonical.version};
}

export function abiPublicContext(query = "") {
  return visibleAbiFacts(query).map(f=>`[${f.id}] [${f.category}; ${f.assertion}; ${f.disclosure}] ${f.text}`).join("\n")
    + "\nUnverified: " + canonical.unknownFields.join("; ")
    + "\nUse ABI伯爵 as the default brand. OWNER CONFIRMED statements describe the owner, beliefs or aims; never turn them into external effects, work content or operating services. Owner curation is not a quality/popularity ranking. Song count ambition is not achievement. Projects have only their explicit status. Do not invent private facts or personal memories.";
}
