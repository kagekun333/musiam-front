## 目的
- [ ] 既存体験を壊さず、機能を一歩前進

## スモーク（手元で実施）
- [ ] /gates で **3カード**が出る
- [ ] 伯爵の門 → /chat で1往復できる
- [ ] /exhibition と /oracle は 404 にならない（準備中OK）

## 変更の種類
- [ ] feat
- [ ] fix
- [ ] chore
- [ ] refactor
- [ ] docs/ci

## 注意
- [ ] `npm run preflight` 済（LOCK/二重ルーターOK）
- [ ] 触った機能を `.musiam/ops/feature-ledger.yaml` に反映
