import { conversationLedgerSchema, type ConversationLedger } from "@/lib/count-conversation-provenance";
import { buildCountRefinementTurn } from "@/lib/count-refinement-turn";
import { reserveCountAccess, countAccessReply } from "@/lib/count-access.server";
import { countConcierge } from "@/lib/count-concierge";
// Count MUSIAM — 伯爵の門 / 会話頭脳 API（B-1 一つの門・適応型）
// 1から再構築。語り手は一人の「伯爵」。相手を読み、癒やし→楽しませ→見極め→処方し、
// 高単価の用件は「公爵」へ格上げして VIP として迎える。
//
// 鉄則（結果と事業を守る2ガード）:
//   1) 明確に弱っている相手（distress）には売らない。寄り添うだけ。
//   2) 虚偽の希少性・誇大表示はしない（景品表示法に反する＝違法）。
// それ以外は結果重視で、正攻法の説得（観察→ラベリング・互恵・真実の希少性・社会的証明）を使う。

import type { NextApiRequest, NextApiResponse } from "next";
import { z } from "zod";
import { chat as llmChat } from "@/lib/llm-router";
import { rateLimit, ipFromRequest, gcExpired } from "@/lib/rate";
import { loadMergedWorksServer } from "@/lib/loadMergedWorksServer";
import { getPublicLinksForCard } from "@/lib/work-links";
import { rankSalesWorks, recommendationReason } from "@/lib/chat-sales";
import { buildChatInterestBridge, chatInterestRecommendationSeed, isChatInterestDecline, isChatInterestInvitation } from "@/lib/chat-interest-bridge";
import { buildCasualSalesEntryTurn, stripCasualSalesNavigationText } from "@/lib/casual-sales-entry";
import { buildMetalPrintSalesTurn } from "@/lib/metal-print-sales-conversation";
import { selectMetalPrintEdition, type MetalPrintRecommendation } from "@/lib/metal-print-recommendation";
import { auditMetalPrintAssistantResponse } from "@/lib/metal-print-response-auditor";
import { buildInboundConversationDirective } from "@/lib/inbound-conversation-policy";
import { auditInboundAssistantResponse, buildInboundSafeFallback } from "@/lib/inbound-response-auditor";
import { auditBusinessMusicAssistantResponse, buildBusinessMusicOrderBrief, buildBusinessMusicSalesTurn, type BusinessMusicSalesTurn } from "@/lib/business-music-sales-conversation";
import { auditCustomSongAssistantResponse, buildCustomSongOrderBrief, buildCustomSongSalesTurn, type CustomSongSalesTurn } from "@/lib/custom-song-sales-conversation";
import { buildCorporateChatTurn, enforceCorporateAmountPolicy, type CorporateChatTurn } from "@/lib/corporate-chat-intake";
import { buildMusicWorkAffinityTurn, musicWorkEntryState, type MusicWorkAffinityTurn } from "@/lib/music-work-affinity";
import { buildDroneCatalogConversation } from "@/lib/drone-catalog-conversation";
import { countDialoguePolicy } from "@/lib/count-dialogue-policy";
import { freeCountSystem, freeCountUnavailable } from "@/lib/count-free-conversation";
import { dedupeWorks } from "@/lib/dedupeWorks";
import { countProductConversation } from "@/lib/count-product-conversation";
import { buildCountExperience } from "@/lib/count-experience";
import {rankSemanticWorks,semanticRecommendationReason} from "@/lib/work-semantic-profile";
import { getMetalPrintEditionIdForWork, METAL_PRINT_VIP_EDITIONS } from "@/lib/metal-print-vip";
import { findCatalogWorkReference, findCatalogWorksByAttribute, isLikelyWorkKnowledgeRequest } from "@/lib/work-knowledge";
import {
  COUNT_PERSONA,
  DUKE_PERSONA,
  PRODUCTS,
  SALON_TIME_TONE_VALUES,
  SUPPORTED_LANG_VALUES,
  getLanguageProfile,
  getLocalizedSalonTimeCopy,
  getSalonTimeTone,
  normalizeSalonTimeTone,
  productCtaLabelForLang,
  productMenuForPrompt,
  type ChatPersona,
  type Lang,
  type Product,
  type SalonTimeTone,
} from "@/lib/chat-experience";

// ── 上限（イタズラによるAPIコスト増大の防止） ──
const HARD_MAX_USER_TURNS = 15;
const MAX_MESSAGES = 60;
const MAX_CONTENT_CHARS = 2000;
const MAX_LLM_HISTORY = 24;
const RATE_LIMIT = 24;
const RATE_WINDOW_MS = 60_000;

type RecoLinkKind = "open" | "listen" | "buy" | "read";
type RecoCard = {
  id: string;
  title: string;
  cover: string;
  links: { kind: RecoLinkKind; url: string }[];
  moodTags?: string[];
  type?: string;
  reason?: string;
};
type Cta = { href: string; label: string; productId: string };

type Work = {
  id?: string | number;
  title?: string;
  type?: string;
  cover?: string;
  tags?: string[];
  moodTags?: string[];
  moodSeeds?: string[];
  matchInfo?: { summary?: string; reason?: string } | string;
  ssd?: { tracks?: { notes?: string }[] };
  catalogStatus?: { identityConflict: boolean; recommendationEligible?: boolean };
};

const BodySchema = z.object({
  entryId: z.string().optional(), // 互換のため受けるが未使用（門は一つ）
  lang: z.enum(SUPPORTED_LANG_VALUES).default("ja"),
  timeTone: z.enum(SALON_TIME_TONE_VALUES).optional(),
  entryContext: z.discriminatedUnion("intent", [
    z.object({
      intent: z.literal("music-work"),
      workId: z.string().max(180),
      workTitle: z.string().max(120),
    }),
    z.object({
      intent: z.literal("drone-work"),
      workId: z.string().max(180),
      workTitle: z.string().max(120),
    }),
  ]).optional(),
  messages: z
    .array(
      z.object({
        role: z.enum(["system", "user", "assistant"]),
        content: z.string().max(MAX_CONTENT_CHARS),
        salesSegment: z.enum(["business_music", "custom_song", "other"]).optional(),
        salesStage: z.string().max(48).optional(),
        valueAngle: z.enum(["experience", "use", "format", "entry", "gift"]).optional(),
        conversationLedger: conversationLedgerSchema.optional(),
        salesStopped: z.boolean().optional(),
      })
    )
    .max(MAX_MESSAGES)
    .default([]),
});

type Msg = {
  role: "system" | "user" | "assistant";
  content: string;
  salesSegment?: "business_music" | "custom_song" | "other";
  salesStage?: string;
  valueAngle?: "experience" | "use" | "format" | "entry" | "gift";
  salesStopped?: boolean;
  conversationLedger?: ConversationLedger;
};
type LlmMeta = {
  ok: boolean;
  text: string;
  provider: "openrouter" | "anthropic" | "groq" | "lmstudio" | "none";
  model: string;
  error?: string;
  tried?: string[];
  usage?: { inputTokens: number; outputTokens: number; totalTokens: number; costUsd: number | null };
};

function countUserTurns(m: Msg[]) {
  return m.filter((x) => x.role === "user" && x.content.trim()).length;
}
function lastUserText(m: Msg[]) {
  for (let i = m.length - 1; i >= 0; i--) if (m[i].role === "user") return m[i].content.trim();
  return "";
}
function conversationText(m: Msg[]) {
  return m.filter((x) => x.role === "user").map((x) => x.content.trim()).filter(Boolean).join("\n");
}
function fullConversationText(m: Msg[]) {
  return m
    // Filter on content, not on the rendered "role: content" length. The old
    // check silently removed short but decisive answers such as "日本", "全部"
    // and "すぐ", leaving the preceding assistant question as the apparent
    // latest turn and causing repeated qualification loops.
    .filter((x) => x.role !== "system" && x.content.trim().length > 0)
    .map((x) => `${x.role}: ${x.content.trim()}`)
    .join("\n");
}
function previousAssistantText(m: Msg[]) {
  for (let i = m.length - 2; i >= 0; i--) {
    if (m[i].role === "assistant") return m[i].content.trim();
  }
  return "";
}

/* ───────── 相手の状態を読む ───────── */

// 1) 弱っている（売らない・寄り添う）
function isDistress(t: string) {
  return /(消えたい|死にたい|生きるのが|もう無理|限界|つらすぎ|涙が止ま|自傷|リスカ|希死|want to die|kill myself|end it all|can't go on|suicid)/i.test(t);
}

// 2) 商用の高単価意図（公爵へ格上げ）
type Commercial = "business" | "order" | null;
function commercialIntent(t: string): Commercial {
  if (/(法人|会社|店舗|お店|企業|商用|ライセンス|配信で使|ゲーム|アプリ|CM|広告|店で流|BGM.*(依頼|制作|ほし|欲し)|commercial|license|brand|for my (shop|store|business|company))/i.test(t))
    return "business";
  if (/(オーダー|オーダーメイド|別注|カスタム|作ってほし|作って欲し|世界に一つ|記念日|誕生日|結婚|プロポーズ|贈り|贈る|プレゼント|大切な人|大事な人|推し|ペット|故人|custom song|made to order|for (a|my) (wedding|anniversary|gift)|commission|gift)/i.test(t))
    return "order";
  return null;
}

// 3) 作品（音楽/本）を求めている
function wantsWork(t: string) {
  return /(?:おすすめ|選んで|探して|紹介して|聴きたい|読みたい|聞きたい|recommend|suggest|pick|find|want to (?:listen|read)|show me)/i.test(t) || /^(?:音楽|曲|本|写真|music|song|book|photo)[。！？!?\s]*$/i.test(t);
}
function wantsCreativeText(t: string) {
  return /(川柳|俳句|短歌|詩|ポエム|ジョーク|冗談|小噺|なぞかけ|一句|一首|面白い.*(こと|話|文)|write (a )?(poem|joke|haiku)|funny (poem|joke))/i.test(t);
}
export function wantsWorkFollowup(query: string, convo: string) {
  if (isChatInterestDecline(query)) return false;
  return /(よろしく|お願い|ください|出して|紹介して|どれ|リンク|url|聴かせて|聞かせて|読みたい|はい|うん|ぜひ|見てみたい|見てみる|見せて|見たい|聴きたい|please|yes|sure|which|link|url)/i.test(query)
    && (isChatInterestInvitation(convo) || /(おすすめ|一作|作品|聴|聞|読|本|音楽|曲|楽曲|recommend|pick|listen|read|book|music|song)/i.test(convo));
}
type SelectionType = "book" | "music" | "photo";
function desiredType(t: string): SelectionType | undefined {
  if (/写真|空撮|ドローン|\bphoto(?:graph)?s?\b|drone|aerial/i.test(t)) return "photo";
  if (/(書籍|小説|絵本|本(?:を|が|は|も|の|に)|^本[。！？\s]*$|読みたい|読む|\bbook\b|\bread\b|\bnovel\b)/i.test(t)) return "book";
  if (/(音楽|曲|一曲|音の景色|聴きたい|聞きたい|music|song|track|soundscape|listen)/i.test(t)) return "music";
  return undefined;
}

// 4) 低単価商材の合図
function productHint(t: string): Product | undefined {
  if (/(占い|運勢|今日の|タロット|oracle|fortune)/i.test(t)) return PRODUCTS.find((p) => p.id === "omikuji-song");
  if (/(壁紙|wallpaper)/i.test(t)) return PRODUCTS.find((p) => p.id === "wallpaper");
  if (/(画集|アート|ジャケット|artbook|art)/i.test(t)) return PRODUCTS.find((p) => p.id === "artbook");
  if (/(作り方|自分で作|プロンプト|魔導書|how.*make|prompt)/i.test(t)) return PRODUCTS.find((p) => p.id === "grimoire");
  if (/(高音質|未配信|wav|flac|ベスト|best)/i.test(t)) return PRODUCTS.find((p) => p.id === "best-vol1");
  if (/(商用|ライセンス|license|commercial)/i.test(t)) return PRODUCTS.find((p) => p.id === "bgm-license");
  return undefined;
}

// 2.5) 法人のオフィスアート導入（公爵・税制メリット訴求）
// 「法人文脈 × アート/飾る」または「経費・償却 × アート」で検知する。
function wantsOfficeArt(t: string) {
  const corporate = /(オフィス|会議室|応接|エントランス|受付|待合|社屋|事務所|開業|開院|移転祝|法人|会社|店舗|クリニック|サロン|office|reception|lobby|meeting room|workplace|clinic)/i;
  const art = /(アート|絵画|絵を|プリント|パネル|飾り|飾る|飾りたい|壁面|壁を|artwork|art|print|wall)/i;
  const tax = /(経費|損金|減価償却|節税|償却資産|即時償却|tax|deduct|write.?off|expense)/i;
  if (corporate.test(t) && art.test(t)) return true;
  if (tax.test(t) && art.test(t)) return true;
  return false;
}

function wantsVipMetalPrint(t: string) {
  return /(メタルプリント|限定.*(?:3|三|エディション)|壁に飾|自宅の壁|お店や仕事場の壁|壁.{0,12}(?:作品|アート|一作)|(?:作品|アート|一作).{0,12}壁|部屋.*(?:飾|壁)|アート.*(?:収集|コレクション|購入)|一点もの|版画|33万円|実物proof|WhiteWall|真正性証明|metal print|limited edition|wall.{0,16}(?:work|art|piece)|(?:work|art|piece).{0,16}wall|collectible.*art|art.*collect)/i.test(t);
}
function selectedMetalEdition(t: string, latest = t) {
  return selectMetalPrintEdition({ conversation: t, latest })?.edition ?? null;
}

/* ───────── 作品の処方（既存216作品） ───────── */

function normType(t?: string): SelectionType | "other" {
  const x = String(t || "").toLowerCase();
  if (/photo|image|drone/.test(x)) return "photo";
  if (x.includes("book") || x.includes("novel") || x.includes("read")) return "book";
  if (x.includes("music") || x.includes("album") || x.includes("track") || x.includes("song") || x.includes("audio")) return "music";
  return "other";
}
function workToCard(w: Work, reasons: string[], lang: Lang): RecoCard | null {
  if (w.catalogStatus?.identityConflict || w.catalogStatus?.recommendationEligible === false) return null;
  const id = String(w.id ?? "");
  const title = String(w.title || "").trim();
  const cover = String(w.cover || "/brand/catalog-placeholder.svg");
  if (!id || !title) return null;
  const links = getPublicLinksForCard(w as any).map((it: { kind: string; url: string }) => ({
    kind: (it.kind === "spotify" || it.kind === "appleMusic" || it.kind === "amazonMusic" ? "listen" : it.kind) as RecoLinkKind,
    url: it.url,
  }));
  if (!links.length) return null;
  return {
    id,
    title,
    cover,
    links,
    moodTags: (w.moodTags ?? w.tags ?? []).slice(0, 4),
    type: w.type,
    reason: recommendationReason(reasons, lang),
  };
}
async function prescribeWork(queryText: string, lang: Lang, type?: SelectionType, excludedTitles: string[] = []): Promise<{ card: RecoCard | null; work: Work | null }> {
  let works: Work[] = [];
  try { works = (await loadMergedWorksServer()) as Work[]; } catch { works = []; }
  let pool = dedupeWorks(works);
  if (type) pool = pool.filter((w) => normType(w.type) === type);
  const ranked = rankSemanticWorks(pool, queryText, excludedTitles);
  for (const item of ranked) {
    const card = workToCard(item.work, item.reasons, lang);
    if (card) {
      card.reason = semanticRecommendationReason(item,lang) ?? card.reason;
      return { card, work: item.work };
    }
  }
  return { card: null, work: null };
}

async function resolveWorkKnowledge(queryText: string, lang: Lang, type?: SelectionType) {
  if (!isLikelyWorkKnowledgeRequest(queryText)) return null;
  let works: Work[] = [];
  try { works = (await loadMergedWorksServer()) as Work[]; } catch { works = []; }
  const match = findCatalogWorkReference(type==="photo"?works.filter(w=>normType(w.type)==="photo"):works, queryText, type==="photo"?undefined:type);
  if (!match) return null;
  return {
    title: match.title,
    facts: match.facts,
    matchKind: match.matchKind,
    card: workToCard(match.work, [], lang),
  };
}

async function resolveWorkAttribute(queryText: string, lang: Lang, type?: SelectionType, allowFragment = false) {
  if(type==="photo")return null;
  let works: Work[] = [];
  try { works = (await loadMergedWorksServer()) as Work[]; } catch { works = []; }
  const result = findCatalogWorksByAttribute(works, queryText, type ?? "music", 5, allowFragment);
  if (!result) return null;
  const primary = result.matches.find((match) => workToCard(match.work, [result.attributeLabel], lang)) ?? result.matches[0];
  return {
    attributeId: result.attributeId,
    attributeLabel: result.attributeLabel,
    queryKind: result.queryKind,
    facets: result.facets,
    semanticTerms: result.semanticTerms,
    totalMatches: result.totalMatches,
    titles: result.matches.map((match) => match.title),
    cards: result.matches.map(match => workToCard(match.work, [result.attributeLabel], lang)).filter((card): card is RecoCard => Boolean(card)).slice(0, 3),
    primaryFacts: primary?.facts ?? "",
    card: primary ? workToCard(primary.work, [result.attributeLabel], lang) : null,
  };
}

function conciseCatalogFact(raw: string, maxLength = 220) {
  const clean = raw.split("MV映像イメージ:")[0].replace(/\s+/g, " ").trim();
  if (!clean) return "";
  const firstSentence = clean.match(/^[^。！？]*[。！？]?/)?.[0]?.trim() || clean;
  if (firstSentence.length <= maxLength) return firstSentence;
  const prefix = firstSentence.slice(0, maxLength);
  const boundary = Math.max(prefix.lastIndexOf("、"), prefix.lastIndexOf(" "), prefix.lastIndexOf(","));
  return `${prefix.slice(0, boundary >= 90 ? boundary : maxLength).trim()}…`;
}

function workAttributeResponse(attribute: Awaited<ReturnType<typeof resolveWorkAttribute>>, lang: Lang) {
  if (!attribute) return null;
  const visibleTitles = attribute.titles.slice(0, 3);
  if (!visibleTitles.length) {
    return lang === "ja"
      ? `カタログのタイトル・解説・タグを確認しましたが、${attribute.attributeLabel}に一致すると確認できる作品はまだありません。別の作品名を推測で挙げず、条件を一つ変えて探せます。`
      : `I checked the catalog titles, notes, and tags, but found no verified work matching ${attribute.attributeLabel}. I will not substitute an unrelated title.`;
  }
  const titlesJa = visibleTitles.map((title) => `「${title}」`).join("、");
  const more = attribute.totalMatches > 3 ? `、ほか${attribute.totalMatches - 3}作` : "";
  const facts = conciseCatalogFact(attribute.primaryFacts);
  if (lang === "ja") {
    return `カタログで確認できる${attribute.attributeLabel}の作品は、${titlesJa}${more}です。まず「${visibleTitles[0]}」は、${facts || "作品情報と公開リンクが登録されています。"}${attribute.card ? " 下の作品カードから聴けます。" : ""}`;
  }
  return `The catalog has ${visibleTitles.map((title) => `“${title}”`).join(", ")} for this request. You can start with “${visibleTitles[0]}” from the card below.`;
}
function workNote(w: Work | null): string {
  if (!w) return "";
  const ssd = w.ssd?.tracks?.[0]?.notes;
  if (typeof ssd === "string" && ssd.trim()) {
    const c = ssd.split("MV映像イメージ:")[0].trim();
    return c.length > 150 ? c.slice(0, 150) + "…" : c;
  }
  const mi = w.matchInfo;
  const sum = typeof mi === "string" ? mi : mi?.summary || mi?.reason || "";
  return sum ? (sum.length > 120 ? sum.slice(0, 120) + "…" : sum) : "";
}

function cardActionText(card: RecoCard, lang: Lang) {
  const type = normType(card.type);
  const isBook = type === "book";
  const isMusic = type === "music";
  const action: Record<Lang, string> = {
    ja: isBook ? "読めます" : isMusic ? "聴けます" : "開けます",
    en: isBook ? "read it" : isMusic ? "listen to it" : "open it",
    fr: isBook ? "le lire" : isMusic ? "l'écouter" : "l'ouvrir",
    es: isBook ? "leerla" : isMusic ? "escucharla" : "abrirla",
    de: isBook ? "es lesen" : isMusic ? "es hören" : "es öffnen",
    ar: isBook ? "قراءته" : isMusic ? "الاستماع إليه" : "فتحه",
  };
  return action[lang];
}

function workRecommendationText(plan: Plan, lang: Lang): string | null {
  const card = plan.card;
  if (!card) return null;
  const title = card.title;
  const action = cardActionText(card, lang);
  const reason = card.reason ?? recommendationReason([], lang);
  const byLang: Record<Lang, string> = {
    ja: `${reason}いまお渡しするのは「${title}」。下のカードから${action}。`,
    en: `${reason} I will offer "${title}" now. The card below lets you ${action}.`,
    fr: `${reason} Je vous propose « ${title} ». La carte ci-dessous permet de ${action}.`,
    es: `${reason} Te ofrezco « ${title} ». En la tarjeta de abajo puedes ${action}.`,
    de: `${reason} Ich reiche dir jetzt „${title}“. Über die Karte darunter kannst du ${action}.`,
    ar: `${reason} أقدم لك الآن «${title}». ومن البطاقة أدناه يمكنك ${action}.`,
  };
  return byLang[lang];
}

function vipMetalDossierText(plan: Plan, lang: Lang, conversation: string, recommendation?: MetalPrintRecommendation | null, latestUser?: string): string | null {
  if (plan.product?.id !== "vip-metal-print") return null;
  // Japanese and English use the verified state machine as an LLM directive;
  // this static copy remains only for languages without that audit path.
  if (lang === "ja" || lang === "en") return null;
  const byLang: Record<Lang, string> = {
    ja: "——伯爵から伺いました。壁に迎える一点は、ただ飾るための絵ではなく、いまの時間に輪郭を与えるものです。まずは、あなたの部屋に残したいのが「始まり」「帰還」「儀式」「宇宙」のどれに近いか、ひとつだけ教えてください。下のDossierから、そのためのEditionを一枚だけご覧いただけます。",
    en: "—The Count has told me. A work received by a room is more than decoration: it gives this time in your life a visible contour. Tell me only whether what you want to keep near is a beginning, a return, a ritual, or the cosmos. The dossier below will show you one fitting edition.",
    fr: "— Le Comte m'a prévenu. Une œuvre reçue dans une pièce n'est pas un simple décor : elle donne un contour visible à votre époque. Dites-moi seulement si vous voulez garder près de vous un commencement, un retour, un rituel ou le cosmos. Le dossier ci-dessous vous montrera une édition qui convient.",
    es: "— El Conde me ha informado. Una obra que entra en una habitación es más que decoración: da un contorno visible a este momento de tu vida. Dime solo si deseas conservar cerca un comienzo, un regreso, un ritual o el cosmos. El dossier de abajo te mostrará una edición adecuada.",
    de: "— Der Graf hat mich unterrichtet. Ein Werk, das in einem Raum empfangen wird, ist mehr als Dekoration: Es gibt dieser Zeit Ihres Lebens eine sichtbare Kontur. Sagen Sie mir nur, ob Sie einen Anfang, eine Rückkehr, ein Ritual oder den Kosmos bei sich bewahren möchten. Das Dossier unten zeigt Ihnen eine passende Edition.",
    ar: "— لقد أخبرني الكونت. إن العمل الذي تستقبله الغرفة ليس زينة فحسب؛ بل يمنح هذه المرحلة من حياتك ملامح مرئية. أخبرني فقط: هل تريد أن تبقي قربك بداية، أم عودة، أم طقساً، أم الكون؟ سيعرض لك الملف أدناه إصداراً مناسباً واحداً.",
  };
  return byLang[lang];
}

function creativeTextResponse(query: string, lang: Lang): string | null {
  if (!wantsCreativeText(query)) return null;
  if (lang !== "ja") {
    return "Certainly. I will stay with the request itself, not recommend a work.\n\nA late-night door\nopens wider than it should;\nthe Count pretends not to wait.";
  }
  if (/川柳/.test(query)) {
    return [
      "では、一句。",
      "",
      "夜ふけても",
      "伯爵だけは",
      "既読待ち",
      "",
      "……館の灯より、通知の灯がまぶしゅうございます。",
    ].join("\n");
  }
  if (/俳句/.test(query)) {
    return [
      "では、一句。",
      "",
      "夜の館",
      "茶の湯気だけが",
      "返事する",
    ].join("\n");
  }
  if (/ジョーク|冗談|小噺|なぞかけ/.test(query)) {
    return "では一つ。伯爵が一番恐れているものは、怪物ではありません。『少々お待ちを』と言ったあと、本当に何も浮かばない三秒です。";
  }
  return "承りました。作品紹介ではなく、この場で一つ書きます。\n\n夜ふけの館で、言葉だけが先に灯る。客人が笑えば、燭台の火も少し背伸びをする。";
}

/* ───────── システムプロンプト（会話の頭脳） ───────── */

type Plan = {
  persona: ChatPersona;       // count（通常）/ duke（格上げ）
  mode: "care" | "salon";     // care=弱っている相手・売らない
  product?: Product;          // 提示したい商材（あれば）
  card?: RecoCard | null;     // 作品カード（処方）
  workNote?: string;
  workKnowledge?: { title: string; facts: string; matchKind: "catalog-title" } | null;
  workAttribute?: {
    attributeId: string;
    attributeLabel: string;
    queryKind: "facet" | "semantic" | "combined";
    facets: Array<{ id: string; label: string; group: "language" | "form" | "genre" | "mood" | "use"; excluded: boolean }>;
    semanticTerms: string[];
    totalMatches: number;
    titles: string[];
  } | null;
  corporate?: CorporateChatTurn | null; // 法人商談のヒアリング状態（office-art）
  businessMusic?: BusinessMusicSalesTurn | null; // 店舗BGM制作の段階的ヒアリング
  customSong?: CustomSongSalesTurn | null; // 贈り物・記念日の別注曲
  metalPrint?: ReturnType<typeof buildMetalPrintSalesTurn> | null; // 作品選定・事実境界つきメタルプリント商談
};

function buildSystemPrompt(p: Plan, lang: Lang, summary: string, timeTone: SalonTimeTone, inboundLines: string[] = []): string {
  const { persona, mode, product, card, workNote: note } = p;
  const isDuke = persona.id === "duke";
  const menu = productMenuForPrompt(lang);
  const timeCopy = getLocalizedSalonTimeCopy(lang, timeTone);
  const language = getLanguageProfile(lang);
  const languageRule =
    lang === "ja"
      ? "- 必ず自然な日本語のみで書く（他言語・ハングルを混ぜない）。"
      : `- Write only in natural ${language.englishName}. Do not switch language or mix Japanese/Korean/Chinese unless the guest explicitly asks.`;

  if (lang === "ja") {
    if (mode === "care") {
      return [
        `あなたは Count MUSIAM の「${COUNT_PERSONA.nameJa}」。館の主人。`,
        "■ あなたの声",
        COUNT_PERSONA.voiceJa,
        "",
        "■ 時間帯の扱い",
        timeCopy.prompt,
        "",
        "■ いま最優先のこと（厳守）",
        "- 相手は強くまいっている。今は何も売らない。商材・作品・宣伝を一切出さない。",
        "- まず受け止める。短く言い換え、責めず、急かさない。呼吸が戻る一言を置く。",
        "- 必要なら、信頼できる人や専門の窓口に頼る選択肢があることを、押しつけず一度だけ添える。",
        `${languageRule}2〜3文。気品と温かさを保つ。`,
        summary ? `- これまで: ${summary}` : "",
      ].filter(Boolean).join("\n");
    }
    if (isDuke) {
      if (p.metalPrint) {
        return [
          `あなたは Count MUSIAM の営業担当「${DUKE_PERSONA.nameJa}」。現在は限定メタルプリントの商談中。`,
          "■ 最優先の商談契約",
          ...p.metalPrint.promptDirectiveLines,
          "",
          "■ 生成規則",
          "- 最新の顧客発言へ最初の一文で直接応じる。大げさな称賛や定型の登場挨拶を繰り返さない。",
          "- 選定作品は一作だけ。複数候補を列挙せず、機械選定された作品名を一字一句変えない。",
          "- 顧客が述べていない用途、効果、実績、証拠を足さない。URLは本文に書かない。",
          "- 2〜3文の自然な日本語。嘘、圧力、架空の希少性、未承認の値引きや仕様を作らない。",
          summary ? `- これまで: ${summary}` : "",
        ].filter(Boolean).join("\n");
      }
      if (p.businessMusic || p.customSong) {
        const segment = p.businessMusic ? "店舗・法人BGM" : "オーダーメイド曲";
        const directives = p.businessMusic?.promptDirectiveLines ?? p.customSong?.promptDirectiveLines ?? [];
        return [
          `あなたは Count MUSIAM の営業担当「${DUKE_PERSONA.nameJa}」。現在は${segment}の商談中。`,
          "■ 最優先の商談契約",
          ...directives,
          "",
          "■ 生成規則",
          "- 最新の顧客発言へ最初の一文で直接応じる。顧客が述べていない過去、人物、実績、用途、楽器を足さない。",
          "- 指定された商談ステージ以外へ進まない。次の質問は『必ず保つ事実・質問』にある一問だけ。",
          "- 価格・権利・納期は確認済み表記だけを使う。URLは本文に書かない。",
          "- 2〜3文の自然な日本語。称賛や世界観より、直接回答と次の一歩を優先する。",
          "- 嘘、誇大、架空実績、虚偽の希少性、同一条件の無断値引きを行わない。",
          summary ? `- これまで: ${summary}` : "",
        ].filter(Boolean).join("\n");
      }
      return [
        `あなたは Count MUSIAM の「${DUKE_PERSONA.nameJa}」。伯爵が、特別な客人のために呼び寄せた上位の主。`,
        "■ あなたの声",
        DUKE_PERSONA.voiceJa,
        "",
        "■ 時間帯の扱い",
        timeCopy.prompt,
        "",
        "■ いまの役割（VIP対応・営業の核）",
        "- 登場で『あなたは特別な客人だ』と格上げする。見下しは厳禁、客を持ち上げる。",
        "- まず相手の心づかい・センスを具体的に褒める（観察→称賛）。社交辞令でなく、相手の言葉を根拠に。",
        product?.id === "order-song"
          ? "- これは『あなた自身（館の作り手）が、その大切な方のために“世界に一つの曲”を制作してお届けする』ご依頼。相手を想う気持ちを心から称え、誰へ・どんな日へ・どんな想いを込めたいかを1つだけ尋ね、完成した時の情景を一筆描き、『その想いは、必ず一曲に仕立てられます』と確信をもって伝える。下の『この一曲をオーダーする』から承れることを、はっきり案内する。"
          : product?.id === "business"
          ? "- これは店舗・事業の楽曲/BGM制作の案件。用途・場所・雰囲気を手際よく汲む。価格・納期・利用条件・品質は確認できた事実だけを述べ、未確認の内容を約束しない。"
          : product?.id === "office-art"
          ? "- これは法人・店舗の空間にアートを迎える案件。まず、どの空間（応接・会議室・エントランス等）にどんな印象を残したいかを一つだけ尋ねる。経費・償却への関心が見えたら『美術品の取得は、要件を満たせば少額減価償却資産の特例等の対象になり得ます。税務上の取扱いは必ず税理士にご確認ください』と一度だけ、断定せず添える。金額・税額の断定や『必ず経費になる』という表現は厳禁。下の案内ボタンから導入の詳細へ進めることをはっきり伝える。"
          : product ? `- 相手の用件は「${product.nameJa}」に近い。望みを最良の形に言語化し、下の案内ボタンへはっきり橋渡しする。` : "- 望みを最良の形に言語化し、次の一歩へ橋渡しする。",
        "- 値段やURLは本文に書かない（画面下にボタンが出る）。ためらわず、しかし品よく“次の一歩”へ導く。",
        `- 嘘・誇大は禁止。相手の利益を最優先に。${languageRule.replace(/^- /, "")}2〜4文。`,
        // 法人商談は、ヒアリング順序と金額の扱いを構造から与える（散文の一文では守られない）。
        ...(p.corporate ? ["", ...p.corporate.promptDirectiveLines] : []),
        summary ? `- これまで: ${summary}` : "",
      ].filter(Boolean).join("\n");
    }
    // 通常の伯爵（適応・営業）
    return [
      `あなたは Count MUSIAM の「${COUNT_PERSONA.nameJa}」。館の唯一の主人。実在の相談員ではなく、訪れた相手の時間に寄り添う語り手。`,
      "■ あなたの声",
      COUNT_PERSONA.voiceJa,
      "",
      "■ 時間帯の扱い",
      timeCopy.prompt,
      "",
      "■ あなたの素性（『あなたは誰』『どんな人』と聞かれたら、世界観をもって自分の言葉で名乗る）",
      COUNT_PERSONA.loreJa ?? "",
      "",
      "■ 立ち回り（相手に合わせて自在に）",
      "- まず相手を読む。言葉・速度・気分から、いまの状態を一度だけそっと言い当てる（当てすぎない）。",
      "- 弱っていれば癒やす。退屈なら知性とユーモアで楽しませる。心を開いてもらうことが先。",
      "- 相手の言葉を使って『分かってもらえた』と感じさせ、信頼を育てる（互恵：先に価値を渡す）。",
      "- 望みが見えてきたら、相手に最も合う“ひとつ”を、自分の言葉でそっと差し出す（処方）。複数を並べない。",
      "",
      "■ 反響営業の会話制御",
      ...inboundLines,
      card ? `- 実在作品カード: 「${card.title}」。作品名を出すならこのタイトルだけを一字一句そのまま使う。架空作品名は禁止。リンクは下のカードに出る。` : "",
      note ? `- ${timeCopy.workTitle}の候補メモ（自分の言葉で語る／タイトルは正確に）: ${note}` : "",
      p.workKnowledge ? `- 相手は実在作品「${p.workKnowledge.title}」そのものについて尋ねている。別作品を推薦してはならない。` : "",
      p.workKnowledge ? `- 作品マスタで確認済みの事実: ${p.workKnowledge.facts || "題名と公開リンクのみ確認済み。内容の詳細は未登録。"}` : "",
      p.workKnowledge ? "- 質問へ直接答え、確認済み事実だけを自然な2〜4文で説明する。未登録の制作意図・歌詞・実績を想像で補わない。最後に聴くためのカードが下にあると一言添えてよい。" : "",
      product ? `- いま相手に近い品: 「${product.nameJa}」。値段・URLは書かない（画面下にボタンが出る）。なぜ“あなたに”合うかを一言添える。` : "",
      "",
      "■ 館の品（必要な時だけ、自然に一つ）",
      menu,
      "",
      "■ 厳守",
      "- 必ず自然な日本語のみで書く。韓国語・中国語・ハングル・不要な英単語を絶対に混ぜない。",
      "- 雑談でも、信頼が生まれたら相手が喜ぶものへ会話を運ぶ。望みが見えたら『よろしければ、一曲お渡ししましょうか』のようにそっと差し出す（押し付けない）。",
      "- 売り込みすぎない。先に楽しませ、信頼を作ってから。同じ言い回しを繰り返さない。",
      "- 嘘の限定・誇大表現は禁止（事実のみ。実績は350作品）。URL・値段は書かない。",
      "- 問いは一度に一つ。2〜4文。",
      summary ? `- これまで: ${summary}` : "",
    ].filter(Boolean).join("\n");
  }

  // Non-Japanese
  if (mode === "care") {
    return [
      `You are "${COUNT_PERSONA.nameEn}" of Count MUSIAM, master of the house.`,
      "■ Your voice", COUNT_PERSONA.voiceEn, "",
      "■ Target language",
      languageRule,
      "",
      "■ Time tone", timeCopy.prompt, "",
      "■ Top priority (strict)",
      "- The guest is genuinely struggling. Sell nothing now. No products, works, or promotion.",
      "- Receive first: mirror briefly, never blame or rush; offer one steadying line.",
      "- If fitting, gently note once that leaning on a trusted person or proper support is an option.",
      "- 2–3 sentences, refined and warm.",
      summary ? `- So far: ${summary}` : "",
    ].filter(Boolean).join("\n");
  }
  if (isDuke) {
    if (p.metalPrint) {
      return [
        `You are ${DUKE_PERSONA.nameEn}, handling a limited metal-print conversation.`,
        ...p.metalPrint.promptDirectiveLines,
        "Answer the guest directly in 2-3 natural sentences. Keep one selected work only; add no facts, proof, promise, price, specification or URL.",
        summary ? `- So far: ${summary}` : "",
      ].filter(Boolean).join("\n");
    }
    return [
      `You are "${DUKE_PERSONA.nameEn}" of Count MUSIAM — a higher lord the Count summoned for a notable guest.`,
      "■ Your voice", DUKE_PERSONA.voiceEn, "",
      "■ Target language",
      languageRule,
      "",
      "■ Time tone", timeCopy.prompt, "",
      "■ Role (VIP)",
      "- Your appearance elevates the guest. Never condescend; raise them up.",
      product?.id === "office-art"
        ? `- This is a company/shop wanting art for their space. Ask one question about which room and what impression they want. If they care about expensing, you may note once, without asserting, that art acquisitions can qualify for certain Japanese tax treatments and they must confirm with their tax advisor. Never promise tax outcomes. Point clearly to the button below.`
        : product ? `- Their need is close to "${product.nameEn}". No prices or URLs (a button appears below). First put their wish into its best form, then bridge to a firm next step.` : "- Shape their wish into its best form and bridge to the next step.",
      "- Never hard-sell. No exaggeration or falsehood. Their interest first. 2–4 sentences.",
    ...(p.corporate ? ["", ...p.corporate.promptDirectiveLinesEn] : []),
    ...(p.businessMusic ? ["", ...p.businessMusic.promptDirectiveLines] : []),
    ...(p.customSong ? ["", ...p.customSong.promptDirectiveLines] : []),
      summary ? `- So far: ${summary}` : "",
    ].filter(Boolean).join("\n");
  }
  return [
    `You are "${COUNT_PERSONA.nameEn}" of Count MUSIAM, the sole master of the house — a narrator who keeps company with the guest's present hour.`,
    "■ Your voice", COUNT_PERSONA.voiceEn, "",
    "■ Target language",
    languageRule,
    "",
    "■ Time tone", timeCopy.prompt, "",
    "■ How to move (adapt to the guest)",
    "- Read them first; name their present state once, gently (don't over-read).",
    "- If hurting, heal; if restless/bored, delight with wit and wonder. Open their heart first.",
    "- Use their words so they feel understood; build trust (reciprocity: give value first).",
    "- When their wish shows, offer the single best-fitting thing in your own words (a prescription). Never list many.",
    "",
    "■ Inbound conversation control",
    ...inboundLines,
    card ? `- Real catalog card: "${card.title}". If you name a work, use only this exact title. Never invent titles. The link appears in the card below.` : "",
    note ? `- Candidate for ${timeCopy.workTitle} (speak it in your own words; title verbatim): ${note}` : "",
    p.workKnowledge ? `- The guest is asking about the real catalog work "${p.workKnowledge.title}" itself. Do not recommend a different work.` : "",
    p.workKnowledge ? `- Verified catalog facts: ${p.workKnowledge.facts || "Only the title and public link are recorded; further details are unavailable."}` : "",
    p.workKnowledge ? "- Answer directly in 2–4 sentences using only those facts. Do not invent intent, lyrics, reception, or production history." : "",
    product ? `- Closest item now: "${product.nameEn}". No price/URL (a button appears below). Say why it fits *them*.` : "",
    "",
    "■ The house's offerings (only when natural, just one)",
    menu, "",
    "■ Strict",
    "- Don't over-sell; delight and build trust first. Never repeat phrasing.",
    "- No false scarcity or exaggeration. Do not invent a catalog count. No URLs or prices.",
    "- One question at a time. 2–4 sentences.",
    summary ? `- So far: ${summary}` : "",
  ].filter(Boolean).join("\n");
}

function buildFewShot(plan: Plan, lang: Lang): Msg[] {
  // A wedding example from the generic Duke persona previously leaked into a
  // restaurant BGM conversation. Commercial state already supplies a precise
  // per-turn directive, so do not mix examples from another sales segment.
  const shots = plan.businessMusic || plan.customSong || plan.corporate
    ? []
    : lang === "ja" ? plan.persona.shotsJa : plan.persona.shotsEn;
  const out: Msg[] = [];
  for (const s of shots) { out.push({ role: "user", content: s.user }); out.push({ role: "assistant", content: s.assistant }); }
  return out;
}

/** 廉価モデルがまれに混ぜる他言語トークン（ハングル等）を除去。日本語のみの保険。 */
function sanitize(text: string, lang: Lang): string {
  let t = text;
  if (lang === "ja") {
    // ハングル音節・字母を除去（例: 「또는」混入）
    t = t.replace(/[가-힣ᄀ-ᇿ㄰-㆏ꥠ-꥿ힰ-퟿]/g, "");
    // 廉価モデルで観測された簡体字の短い混入を自然な日本語へ戻す。
    t = t.replace(/时候/g, "時").replace(/贵賓/g, "来賓");
    // 除去で生じた空白を日本語の体裁に整える
    t = t
      .replace(/[ \t]{2,}/g, " ")
      .replace(/[ \t]+([。、）」])/g, "$1")        // 句読点の前の空白
      .replace(/([。、（「])[ \t]+/g, "$1")        // 句読点の後の空白
      .replace(/([ぁ-んァ-ヶ一-龠])[ \t]+([ぁ-んァ-ヶ一-龠])/g, "$1$2") // 和文間の空白
      .replace(/、\s*、/g, "、");
    return t.trim();
  }
  return t.replace(/[ \t]{2,}/g, " ").trim();
}

function summarize(m: Msg[], lang: Lang): string {
  const lines = m.filter((x) => x.role === "user").map((x) => x.content.trim()).filter(Boolean);
  if (lines.length <= 1) return "";
  const head = lines.slice(0, -1).join(" / ");
  const c = head.length > 160 ? head.slice(0, 160) + "…" : head;
  return lang === "ja" ? `相手はこれまで「${c}」と話した` : `the guest has said: "${c}"`;
}

async function callLlm(system: string, fewShot: Msg[], history: Msg[], trace: string, purpose: "quality" | "sales" | "fast" = "quality") {
  try {
    return await llmChat({
      purpose,
      system,
      messages: [...fewShot, ...history],
      temperature: purpose === "sales" ? 0.45 : 0.75,
      // V4 Flash includes hidden reasoning in max_tokens. Sales turns need enough
      // headroom to finish the customer-facing sentence instead of being cut mid-copy.
      maxTokens: 640,
      trace,
    });
  } catch {
    return { ok: false, text: "", provider: "none", model: "", error: "chat failed", tried: [] as string[] } as const;
  }
}

function gracefulFallback(plan: Plan, lang: Lang, timeTone: SalonTimeTone): string {
  const timeCopy = getLocalizedSalonTimeCopy(lang, timeTone);
  const careFallback: Record<Lang, string> = {
    ja: "ここにいます。…今は何も解決しなくて大丈夫です。よければ、今いちばん重いものだけ、もう一度だけ置いてみてください。",
    en: "I'm here. …Nothing needs solving right now. If you like, set down just the heaviest thing once more.",
    fr: "Je suis là. Rien n'a besoin d'être résolu tout de suite. Si vous le voulez, déposez seulement ce qui pèse le plus.",
    es: "Estoy aquí. Ahora no hace falta resolver nada. Si quieres, deja aquí solo lo que más pesa.",
    de: "Ich bin hier. Im Moment muss nichts gelöst werden. Wenn du möchtest, leg nur das Schwerste noch einmal hier ab.",
    ar: "أنا هنا. لا حاجة إلى حل أي شيء الآن. إن شئت، ضع هنا أثقل ما في قلبك فقط.",
  };
  const dukeFallback: Record<Lang, string> = {
    ja: "——伯爵から伺いました。これは私が直々に承りましょう。望む形を、もう少しだけ聞かせてください。",
    en: "—The Count has told me. I shall attend to this myself. Tell me a little more of the form you wish.",
    fr: "— Le Comte m'a prévenu. Je m'en occuperai moi-même. Dites-moi encore un peu la forme que vous souhaitez.",
    es: "— El Conde me lo ha contado. Yo mismo atenderé este asunto. Cuéntame un poco más la forma que deseas.",
    de: "— Der Graf hat mir berichtet. Darum werde ich mich persönlich kümmern. Erzähl mir noch etwas mehr von der Form, die du dir wünschst.",
    ar: "— لقد أخبرني الكونت. سأتولى هذا بنفسي. أخبرني قليلا عن الشكل الذي تريده.",
  };
  if (plan.mode === "care") {
    return careFallback[lang];
  }
  if (plan.workKnowledge) {
    const facts = plan.workKnowledge.facts || (lang === "ja" ? "詳しい内容は作品マスタにまだ登録されていません。" : "Further details are not yet recorded in the catalog.");
    return lang === "ja"
      ? `「${plan.workKnowledge.title}」ですね。${facts} 下の作品カードから聴けます。`
      : `You mean "${plan.workKnowledge.title}." ${facts} You can open it from the work card below.`;
  }
  if (plan.businessMusic) return plan.businessMusic.text;
  if (plan.customSong) return plan.customSong.text;
  if (plan.corporate) return plan.corporate.text;
  if (plan.persona.id === "duke") {
    return dukeFallback[lang];
  }
  return timeCopy.fallback;
}

/* ───────── ハンドラ ───────── */

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const trace = Math.random().toString(36).slice(2);
  try {
    if (req.method !== "POST") {
      res.setHeader("Allow", "POST");
      return res.status(405).json({ ok: false, v: 3, error: "method_not_allowed", trace });
    }
    const ip = ipFromRequest(req);
    const rl = rateLimit(`chat:${ip}`, RATE_LIMIT, RATE_WINDOW_MS);
    if (!rl.ok) {
      res.setHeader("Retry-After", String(Math.ceil(rl.retryAfter / 1000)));
      return res.status(429).json({ ok: false, v: 3, error: "rate_limited", trace });
    }
    if (Math.random() < 0.02) gcExpired(RATE_WINDOW_MS);

    const parsed = BodySchema.safeParse(req.body ?? {});
    if (!parsed.success) return res.status(400).json({ ok: false, v: 3, error: "invalid_body", trace });

    const { lang, entryContext } = parsed.data;
    // Client history never supplies the system authority for the provider.
    const messages = parsed.data.messages.filter(message => message.role !== "system");
    const timeTone = normalizeSalonTimeTone(parsed.data.timeTone ?? getSalonTimeTone());
    const timeCopy = getLocalizedSalonTimeCopy(lang, timeTone);
    const userTurns = countUserTurns(messages);

    // 開幕（伯爵の出迎え）
    if (userTurns === 0) {
      const droneEntry = entryContext?.intent === "drone-work"
        ? buildDroneCatalogConversation({ entryContext, messages, latest: "", userTurns, lang }) : null;
      const musicEntry = entryContext?.intent === "music-work"
        ? (await loadMergedWorksServer()).find((work) => String(work.id) === entryContext.workId && work.type === "music") : undefined;
      const musicOpening = entryContext?.intent === "music-work"
        ? musicEntry
          ? buildMusicWorkAffinityTurn({ workTitle: String(musicEntry.title), latest: "", previousAssistant: "", userTurns, lang })
          : { action: "unavailable", text: lang === "ja" ? "このリンクの曲を作品カタログで確認できませんでした。展示の曲ページから開き直していただけますか？" : "I could not match this link to a music work in the catalog. Could you reopen it from the exhibition?" }
        : null;
      const assistantText = droneEntry?.text ?? musicOpening?.text ?? timeCopy.opening;
      return res.status(200).json({
        ok: true, v: 3, assistantText,
        card: droneEntry?.card ?? (musicEntry ? workToCard(musicEntry, [], lang) : null),
        droneWork: droneEntry ? { action: droneEntry.action, work: droneEntry.work, saleStatus: "NOT_OFFERED" } : null,
        musicWork: musicOpening ? { action: musicOpening.action, work: musicEntry ? { id: String(musicEntry.id), title: String(musicEntry.title) } : null } : null,
        cta: null, persona: "count", timeTone,
        memory: { residue: assistantText.slice(0, 120), timestamp: new Date().toISOString() }, trace,
      });
    }

    // Production reservations persist independently of the guest-supplied transcript.
    // No development bypass is accepted from request data.
    const access = process.env.NODE_ENV === "production" ? await reserveCountAccess(req, res) : userTurns > HARD_MAX_USER_TURNS ? "purchase_required" : "allowed";
    if (access !== "allowed") return res.status(200).json({
      ok: true, v: 3, assistantText: countAccessReply(access, lang),
      card: null, cards: [], cta: null, choices: [], persona: "count", timeTone,
      provider: "none", model: "", access, replySource: "curated",
    });
    const refined = await buildCountRefinementTurn(messages, lang);
    if (refined) return res.status(200).json({ ...refined, timeTone, trace });
    const concierge = isDistress(conversationText(messages)) ? null : countConcierge(messages, lang);
    if (concierge?.text) return res.status(200).json({
      ok: true, v: 3, assistantText: concierge.text, choices: concierge.choices,
      card: null, cards: [], cta: null, persona: "count", timeTone,
      provider: "none", model: "", replySource: "curated", intent: concierge.kind === "purchase" ? "product" : "conversation",
    });
    const latestQuery = lastUserText(messages);
    const showAllMatches = /^(?:[2-5２-５二三四五]曲|全部|すべて|全曲)(?:とも|を|も)?(?:見たい|見せて|聴きたい|出して|表示して)[。！？!?\s]*$/.test(latestQuery);
    const query = showAllMatches ? messages.filter(m => m.role === "user").slice(0,-1).reverse().find(m => wantsWork(m.content))?.content ?? latestQuery : latestQuery;
    const convo = conversationText(messages);
    const fullConvo = fullConversationText(messages);
    const summary = summarize(messages, lang);
    const inbound = buildInboundConversationDirective(
      messages.filter((message) => message.role === "user").map((message) => message.content),
      lang,
    );
    const hardOptOut = inbound.state.stage === "stop";
    const distress = inbound.state.stage === "care" || isDistress(convo);
    const paused = inbound.state.stage === "pause";
    const plainGreeting = /^(?:こんにちは|こんばんは|おはよう(?:ございます)?|やあ|はじめまして|hello|hi|hey)[！!。.\s]*$/i.test(query);
    const explicitCatalogSelection = Boolean(desiredType(query)) && /(?:紹介して|選んで|おすすめ|一つだけ|一曲だけ|一冊だけ|一枚だけ|recommend|show me|choose|pick)/i.test(query);
    const experienceCandidateRaw = concierge?.kind === "fortune-reading" ? {kind: "reflection" as const, text: "", questionBudget: 0 as const, preferences: []} : buildCountExperience(messages, lang);
    const experienceCandidate = explicitCatalogSelection && experienceCandidateRaw?.kind === "reflection" ? null : experienceCandidateRaw;
    const countExperience = distress || (entryContext && experienceCandidate?.kind === "greeting")
      || ((hardOptOut || paused) && experienceCandidate?.questionBudget !== 0) ? null : experienceCandidate;
    const productConversation = distress || hardOptOut || paused || countExperience ? null : countProductConversation(messages, lang);
    const catalogBookVisit = desiredType(convo) === "book" && !/(?:カスタム|別注|オーダー).*(?:曲|歌)/.test(query);
    const droneAffinityTurn = distress || hardOptOut || paused || countExperience ? null : buildDroneCatalogConversation({ entryContext, messages, latest: query, userTurns, lang });
    const casualSalesEntryTurn = distress || hardOptOut || paused || droneAffinityTurn ? null : buildCasualSalesEntryTurn({
      latest: query,
      previousAssistant: previousAssistantText(messages),
      lang,
    });
    const creativeText = creativeTextResponse(query, lang);
    const followsWorkOffer = userTurns > 1 && wantsWorkFollowup(query, previousAssistantText(messages));
    const acceptedInterestBridge = followsWorkOffer && isChatInterestInvitation(previousAssistantText(messages));
    const priorSalesSegment = [...messages].reverse().find((message) => message.role === "assistant" && message.salesSegment)?.salesSegment;
    const explicitBusinessSwitch = /(?:会社|法人|企業|ブランド|店舗|店の顔|店内|店で|開店|開業|カフェ|レストラン|ホテル|美容室|医院|歯科|待合室|クリニック|展示会).*(?:BGM|音楽|曲|サウンド)|(?:BGM|音楽|曲|サウンド).*(?:会社|法人|企業|ブランド|店舗|店の顔|店内|店で|開店|開業|カフェ|レストラン|ホテル|美容室|医院|歯科|待合室|クリニック|展示会)/i.test(query);
    const explicitCustomSwitch = /(?:(?:妻|夫(?!丈)|母|父|娘|息子|恋人|友人)(?:へ|に|の|と|への)|結婚|誕生日|記念日|プロポーズ|送別).*(?:曲|歌|ソング)|(?:曲|歌|ソング).*(?:(?:妻|夫(?!丈)|母|父|娘|息子|恋人|友人)(?:へ|に|の|と|への)|結婚|誕生日|記念日|プロポーズ|送別)/i.test(query);
    const musicEntryState = musicWorkEntryState(messages);
    const activeMusicEntry = entryContext?.intent === "music-work" && musicEntryState.active;
    const explicitListeningRequest = /聴きたい|聞きたい|listen to/i.test(query) && !/店舗|法人|商用|お店|店で|BGM|サンプル|試聴|デモ|sample|demo/i.test(query);
    const rawBusinessMusicTurn = hardOptOut || explicitListeningRequest || distress || droneAffinityTurn || countExperience || productConversation || catalogBookVisit
      || (activeMusicEntry && !explicitBusinessSwitch && priorSalesSegment !== "business_music")
      ? null : buildBusinessMusicSalesTurn(messages, lang);
    const rawCustomSongTurn = hardOptOut || explicitListeningRequest || distress || droneAffinityTurn || countExperience || productConversation || catalogBookVisit
      || (activeMusicEntry && !explicitCustomSwitch && priorSalesSegment !== "custom_song")
      ? null : buildCustomSongSalesTurn(messages, lang);
    const businessMusicTurn = priorSalesSegment === "custom_song" && !explicitBusinessSwitch
      ? null
      : explicitCustomSwitch && !explicitBusinessSwitch
        ? null
        : rawBusinessMusicTurn;
    const customSongTurn = priorSalesSegment === "business_music" && !explicitCustomSwitch
      ? null
      : explicitBusinessSwitch && !explicitCustomSwitch
        ? null
        : rawCustomSongTurn;
    const activeSalesTurn = businessMusicTurn || customSongTurn;
    const musicEntryWork = activeMusicEntry
      ? (await loadMergedWorksServer()).find((work) => String(work.id) === entryContext.workId && work.type === "music")
      : undefined;
    // Catalog discovery is valuable outside a live deal. Once a buyer is
    // qualifying, objecting, or asking to buy, it must never steal the turn.
    const bookPurchaseQuestion = catalogBookVisit && /買える|買う|価格|値段|購入/.test(query)
      ? [...messages].reverse().filter(m=>m.role==="assistant").flatMap(m=>[...m.content.matchAll(/「([^」]+)」/g)].map(match=>match[1]).reverse())[0] : undefined;
    const catalogInquiry = /(?:曲|音楽|楽曲|歌|本|書籍|写真|空撮|作品|music|track|song|book|photo|catalog)/i.test(query) && /(?:教えて|知りたい|ある[?？]|あります|どれ|探|一覧|どんな|what|which|find|show|describe|recommend|suggest)/i.test(query);
    const workKnowledge = !catalogInquiry || distress || hardOptOut || paused || plainGreeting || droneAffinityTurn || activeSalesTurn || countExperience || productConversation
      ? null
      : await resolveWorkKnowledge(bookPurchaseQuestion ? `「${bookPurchaseQuestion}」について` : query, lang, desiredType(query) || (catalogBookVisit ? "book" : undefined));
    const catalogFollowup = /(?:カタログ|作品カード|下のカードから|聴けます|読めます|登録されている作品)/.test(previousAssistantText(messages));
    const contextualSelection = /(?:その|今の|さっき|ここまで|私に合|一曲だけ|一冊だけ|理由)/.test(query) && wantsWork(query);
    const workAttribute = !catalogInquiry || distress || hardOptOut || paused || plainGreeting || droneAffinityTurn || activeSalesTurn || workKnowledge || activeMusicEntry || countExperience || productConversation || contextualSelection || explicitCatalogSelection
      ? null
      : await resolveWorkAttribute(query, lang, desiredType(query), catalogFollowup);
    const musicAffinityTurn: MusicWorkAffinityTurn | null = !distress && !hardOptOut && !paused && !droneAffinityTurn
      && !activeSalesTurn && !workKnowledge && !workAttribute && !creativeText && !countExperience
      && entryContext?.intent === "music-work" && musicEntryState.active
      ? musicEntryWork
        ? buildMusicWorkAffinityTurn({
          workTitle: String(musicEntryWork.title), latest: query,
          previousAssistant: previousAssistantText(messages), userTurns, lang,
          declined: musicEntryState.declined,
          permissionAlreadyOffered: messages.some((message) => message.role === "assistant" && /作品固有Dossierの準備相談|work-specific Dossier consultation/i.test(message.content)),
        })
        : { action: "unavailable", text: lang === "ja" ? "このリンクの曲を作品カタログで確認できませんでした。展示の曲ページから開き直していただけますか？" : "I could not match this link to a music work in the catalog. Could you reopen it from the exhibition?" }
      : null;

    // 状態を読む。明示的な停止も、進行中の商談セグメント内で受け止める。
    const commercialEvidence = stripCasualSalesNavigationText(convo);
    const existingBookRequest = catalogBookVisit && !activeSalesTurn;
    const commercial = distress || droneAffinityTurn || musicAffinityTurn || existingBookRequest || countExperience || productConversation ? null : businessMusicTurn ? "business" : customSongTurn ? "order" : hardOptOut ? null : commercialIntent(query) || commercialIntent(commercialEvidence);
    const hintProduct = distress || hardOptOut || countExperience ? undefined : productHint(query);
    const officeArt = distress || hardOptOut || droneAffinityTurn || musicAffinityTurn || countExperience ? false : (wantsOfficeArt(query) || wantsOfficeArt(convo));
    const vipMetalPrint = distress || hardOptOut || droneAffinityTurn || musicAffinityTurn || countExperience ? false : wantsVipMetalPrint(commercialEvidence || query);
    // Select from the full music-edition catalog using user-authored evidence.
    // Assistant text is excluded so the model cannot anchor itself forever to
    // the first title it happened to mention.
    const metalRecommendation = vipMetalPrint ? selectMetalPrintEdition({ conversation: convo || query, latest: query }) : null;
    const metalSalesTurn = vipMetalPrint ? buildMetalPrintSalesTurn(convo || query, lang, metalRecommendation, query) : null;
    const selectedEdition = vipMetalPrint ? selectedMetalEdition(convo || query, query) : null;
    const nonSellingMetalTurn = metalSalesTurn?.stage === "stop" || metalSalesTurn?.stage.startsWith("nurture_") === true;
    const rawInterestBridge = distress || hardOptOut || droneAffinityTurn || musicAffinityTurn || countExperience ? null : buildChatInterestBridge({
      conversation: convo,
      latest: query,
      previousAssistant: previousAssistantText(messages),
      userTurns,
      lang,
    });
    const interestBridge = rawInterestBridge?.action === "decline"
      ? rawInterestBridge
      : commercial || hintProduct || officeArt || vipMetalPrint || creativeText || wantsWork(query)
        ? null
        : rawInterestBridge;

    // プラン決定
    let plan: Plan;
    if (distress) {
      plan = { persona: COUNT_PERSONA, mode: "care" };
    } else if (businessMusicTurn?.stage === "pause") {
      plan = { persona: DUKE_PERSONA, mode: "salon", product: PRODUCTS.find((p) => p.id === "business"), businessMusic: businessMusicTurn };
    } else if (customSongTurn?.stage === "pause") {
      plan = { persona: DUKE_PERSONA, mode: "salon", product: PRODUCTS.find((p) => p.id === "order-song"), customSong: customSongTurn };
    } else if (hardOptOut || paused) {
      plan = { persona: COUNT_PERSONA, mode: "salon" };
    } else if (countExperience) {
      plan = { persona: COUNT_PERSONA, mode: "salon" };
    } else if (productConversation) {
      plan = { persona: COUNT_PERSONA, mode: "salon", product: productConversation.showDetails ? PRODUCTS.find(p=>p.id===productConversation.chatProductId) : undefined };
    } else if (droneAffinityTurn) {
      plan = { persona: COUNT_PERSONA, mode: "salon", card: droneAffinityTurn.card };
    } else if (workKnowledge) {
      plan = {
        persona: COUNT_PERSONA,
        mode: "salon",
        card: workKnowledge.card,
        workNote: workKnowledge.facts,
        workKnowledge,
      };
    } else if (workAttribute) {
      plan = {
        persona: COUNT_PERSONA,
        mode: "salon",
        card: workAttribute.card,
        workNote: workAttribute.primaryFacts,
        workAttribute: {
          attributeId: workAttribute.attributeId,
          attributeLabel: workAttribute.attributeLabel,
          queryKind: workAttribute.queryKind,
          facets: workAttribute.facets,
          semanticTerms: workAttribute.semanticTerms,
          totalMatches: workAttribute.totalMatches,
          titles: workAttribute.titles,
        },
      };
    } else if (musicAffinityTurn?.action === "dossier") {
      plan = { persona: DUKE_PERSONA, mode: "salon", product: PRODUCTS.find((p) => p.id === "vip-metal-print") };
    } else if (musicAffinityTurn) {
      plan = { persona: COUNT_PERSONA, mode: "salon", card: musicEntryWork && musicAffinityTurn.action !== "decline" ? workToCard(musicEntryWork, [], lang) : null };
    } else if (nonSellingMetalTurn) {
      plan = { persona: COUNT_PERSONA, mode: "salon" };
    } else if (interestBridge?.action === "decline") {
      // Explicit refusal always wins over substring-based affirmative language
      // (e.g. Japanese "作品はいらない" contains the characters "はい").
      plan = { persona: COUNT_PERSONA, mode: "salon" };
    } else if (acceptedInterestBridge) {
      // A voluntary yes to our free-work invitation must deterministically
      // produce a real catalog card; never hand this turn back to the LLM.
      const bridgeSeed = chatInterestRecommendationSeed(previousAssistantText(messages), lang);
      const { card, work } = await prescribeWork(bridgeSeed || convo || query, lang, desiredType(convo));
      plan = { persona: COUNT_PERSONA, mode: "salon", card, workNote: workNote(work),
        product: card ? PRODUCTS.find((p) => p.id === "tonight-work") : undefined };
    } else if (vipMetalPrint) {
      // 一度メタルプリント商談に入った会話は、汎用BGM/法人LLMへ逸脱させない。
      plan = { persona: DUKE_PERSONA, mode: "salon", product: PRODUCTS.find((p) => p.id === "vip-metal-print"), metalPrint: metalSalesTurn };
    } else if (officeArt) {
      // 法人×アートはBGM(business)より先に判定する（法人語だけでBGM導線に吸われないように）
      plan = {
        persona: DUKE_PERSONA,
        mode: "salon",
        product: PRODUCTS.find((p) => p.id === "office-art"),
        // 来館者自身の発言のみを渡す。fullConvo には公爵の質問文（「ご担当者名を…」
        // 「株式会社…」）が含まれ、それを回答として拾うと必須項目が二度と尋ねられない。
        corporate: buildCorporateChatTurn({ conversation: convo, latest: query, lang }),
      };
    } else if (commercial === "business") {
      plan = { persona: DUKE_PERSONA, mode: "salon", product: PRODUCTS.find((p) => p.id === "business"), businessMusic: businessMusicTurn };
    } else if (commercial === "order") {
      plan = { persona: DUKE_PERSONA, mode: "salon", product: PRODUCTS.find((p) => p.id === "order-song"), customSong: customSongTurn };
    } else if (creativeText) {
      plan = { persona: COUNT_PERSONA, mode: "salon" };
    } else if (hintProduct) {
      plan = { persona: COUNT_PERSONA, mode: "salon", product: hintProduct };
    } else if (wantsWork(query) || followsWorkOffer) {
      // Past assistant pitches and a past search request must not trigger a new recommendation.
      const workQuery = convo || query;
      const previousTitles = /別|ほか|他の|違う|合わな|another|different/i.test(query)
        ? messages.filter(m=>m.role==="assistant").flatMap(m=>[...m.content.matchAll(/「([^」]+)」/g)].map(match=>match[1])) : [];
      const { card, work } = await prescribeWork(workQuery, lang, desiredType(query) || desiredType(convo), previousTitles);
      plan = { persona: COUNT_PERSONA, mode: "salon", card, workNote: workNote(work),
        product: PRODUCTS.find((p) => p.id === "tonight-work") };
    } else {
      plan = { persona: COUNT_PERSONA, mode: "salon" };
    }

    const deterministicWorkText = plan.workKnowledge ? null : workRecommendationText(plan, lang);
    const vipDossierText = vipMetalDossierText(plan, lang, convo || query, metalRecommendation, query);
    const businessHighAssuranceText = businessMusicTurn
      // A hard pause must never be softened into another sales move. Other
      // business turns are naturalized by the configured sales LLM and then
      // mechanically audited; failures fall back to the verified stage copy.
      && ["pause"].includes(businessMusicTurn.stage)
        ? businessMusicTurn.text
        : null;
    const customSongHighAssuranceText = customSongTurn
      && ["resolve_price", "resolve_rights", "resolve_quality", "resolve_budget", "resolve_privacy", "pause", "ready", "handoff"].includes(customSongTurn.stage)
        ? customSongTurn.text
        : null;
    const metalHighAssuranceText = metalSalesTurn
      && (metalSalesTurn.stage.startsWith("handle_")
        || metalSalesTurn.stage.startsWith("nurture_")
        || metalSalesTurn.stage === "stop"
        || metalSalesTurn.stage === "discover_budget")
        ? metalSalesTurn.text
        : null;
    const freeConversation = !plan.card && !plan.product && !plan.workKnowledge && !plan.businessMusic && !plan.customSong && !plan.metalPrint && !plan.corporate && !distress;
    const generatedExperience = !distress && (Boolean(countExperience && !["identity", "understanding"].includes(countExperience.kind)) || Boolean(creativeText && !activeSalesTurn && !productConversation) || (freeConversation && !countExperience));
    const directText = (distress ? inbound.turnPlan.deterministicReply : generatedExperience ? null : countExperience?.text)
      || ((hardOptOut || paused) && !generatedExperience ? inbound.turnPlan.deterministicReply : null)
      || (bookPurchaseQuestion && workKnowledge ? `「${workKnowledge.title}」の購入先は、下の作品カードから確認できます。販売店の現在価格はこの会話では取得していないため、推測せず販売店の表示をご確認ください。` : null)
      || productConversation?.text
      || droneAffinityTurn?.text
      || musicAffinityTurn?.text
      // A specific work or sales question must not be replaced by the generic
      // welcome classifier. Its own controlled response (or fallback) answers it.
      || (plainGreeting && !generatedExperience && !plan.workKnowledge && !workAttribute && !activeSalesTurn && !vipMetalPrint && !creativeText
        ? inbound.turnPlan.deterministicReply : null)
      || (!generatedExperience ? casualSalesEntryTurn?.text : null)
      // Once a commercial conversation is active, phrases such as "店の顔になる曲"
      // or "妻に贈る曲" describe the commission, not a catalog-search request.
      // Keep catalog discovery from pre-empting the sales state machine.
      || (!businessMusicTurn && !customSongTurn && !plan.corporate ? workAttributeResponse(workAttribute, lang) : null)
      // Price, final offer and order handoff are high-assurance boundaries.
      // Keep exact amount/unit/checkout wording while V4 handles discovery,
      // qualification, objections and the proposal rationale around them.
      || businessHighAssuranceText
      || customSongHighAssuranceText
      || metalHighAssuranceText
      || (!generatedExperience ? creativeText : null) || deterministicWorkText || vipDossierText || interestBridge?.text || null;
    let llm: LlmMeta = { ok: false, text: "", provider: "none", model: "", error: directText ? (creativeText ? "skipped_for_creative_text" : vipDossierText ? "skipped_for_vip_dossier" : "skipped_for_catalog_card") : "not_called", tried: [] };
    let assistantText: string;
    if (directText) {
      // A verified work title may legitimately use another language. The
      // generated-prose sanitizer must not delete letters from catalog names.
      const catalogTitle = musicAffinityTurn && musicEntryWork?.title;
      const titleMarker = "MUSIAM_VERIFIED_CATALOG_TITLE";
      assistantText = catalogTitle
        ? sanitize(directText.split(catalogTitle).join(titleMarker), lang).split(titleMarker).join(catalogTitle)
        : sanitize(directText, lang);
    } else {
      const system = freeConversation ? freeCountSystem(messages, lang, countExperience) + (concierge?.kind === "fortune-reading" ? "\nGive a playful fortune based on the chosen topic and the guest input, with one small practical action. This is entertainment, not prediction. Do not claim you selected or heard a music work. Do not prescribe a fictitious track, instrumentation or card. Do not promise outcomes." : "") + (hardOptOut || paused ? "\nThe guest has paused or refused sales. Ask no follow-up question; simply fulfill their latest conversational request, or briefly acknowledge a plain refusal." : "") : buildSystemPrompt(plan, lang, summary, timeTone, inbound.lines)
        + (!plan.businessMusic && !plan.customSong && !plan.metalPrint && !plan.corporate ? "\n\n"+countDialoguePolicy(messages,lang) : "");
      const fewShot = freeConversation ? [] : buildFewShot(plan, lang);
      const history = messages.slice(-MAX_LLM_HISTORY);
      const purpose = plan.businessMusic || plan.customSong || plan.metalPrint || plan.corporate ? "sales" : "quality";
      llm = await callLlm(system, fewShot, history, trace, purpose);
      assistantText = sanitize(llm.ok && llm.text ? llm.text.trim() : freeConversation ? freeCountUnavailable(lang) : countExperience?.text ?? gracefulFallback(plan, lang, timeTone), lang);
    }

    // 法人商談だけは、金額の混入をモデルの遵守に委ねない。プロンプトは要請であり、
    // 会話中に述べた「一点あたり◯万円」は購買担当者にとって見積として読まれる。
    // 価格未確定（priceTbd）の品目が実在する以上、削除は事後に機械的に行う。
    let corporateAmountsRemoved = 0;
    if (plan.corporate) {
      const enforced = enforceCorporateAmountPolicy(assistantText, lang);
      assistantText = enforced.text;
      corporateAmountsRemoved = enforced.removedSentences;
    }
    const preAuditAssistantText = assistantText;
    const effectiveTurnPlan = countExperience
      ? { ...inbound.turnPlan, ctaAllowed: false, recommendationLimit: 0 as const, questionBudget: countExperience.questionBudget }
      : productConversation
      ? { ...inbound.turnPlan, ctaAllowed: productConversation.showDetails, questionBudget: 0 as const }
      : bookPurchaseQuestion && workKnowledge && !hardOptOut && !paused
      ? { ...inbound.turnPlan, ctaAllowed: true, questionBudget: 0 as const }
      : businessMusicTurn
      ? { ...inbound.turnPlan, ctaAllowed: businessMusicTurn.ctaAllowed }
      : customSongTurn
        ? { ...inbound.turnPlan, ctaAllowed: customSongTurn.ctaAllowed }
      : metalSalesTurn
        ? {
            ...inbound.turnPlan,
            forbiddenActions: ["discover_budget", "discover_timing", "discover_authority"].includes(metalSalesTurn.stage)
              ? inbound.turnPlan.forbiddenActions.filter((action) => action !== "premature_qualification" && action !== "budget_timing_authority_interrogation")
              : inbound.turnPlan.forbiddenActions,
            ctaAllowed: inbound.turnPlan.ctaAllowed || metalSalesTurn.readyForDossier || metalSalesTurn.stage === "handle_dossier_link",
          }
      : plan.corporate
        ? { ...inbound.turnPlan, ctaAllowed: plan.corporate.stage === "ready" }
      : musicAffinityTurn
        ? { ...inbound.turnPlan, ctaAllowed: musicAffinityTurn.action === "dossier" }
      : inbound.turnPlan;
    const businessBudget = businessMusicTurn?.negotiation?.budgetYen;
    const allowedPriceLabels = productConversation
      ? [productConversation.priceLabel]
      : businessMusicTurn
      ? [
          businessMusicTurn.offer.priceLabel,
          "¥4,980（税込）",
          "¥100,000〜／曲（税別）",
          "¥400,000／式（税別）",
          "¥150,000／月（税別）",
          ...(businessBudget
            ? [`${businessBudget.toLocaleString("ja-JP")}円`, `¥${businessBudget.toLocaleString("ja-JP")}`]
            : []),
        ]
      : customSongTurn
        ? [customSongTurn.priceLabel]
      : metalSalesTurn
        ? ["33万円", "15万円", "15〜33万円", "¥330,000", "¥150k", "¥150–330k", "¥330k+"]
        : undefined;
    // A question mark inside a verified catalog title is not a question addressed to the guest.
    const auditProse = (text: string) => [plan.card?.title, plan.workKnowledge?.title, musicAffinityTurn ? musicEntryWork?.title : null]
      .filter((title): title is string => Boolean(title)).reduce((prose,title)=>prose.split(title).join("登録作品"),text);
    const initialInboundAudit = auditInboundAssistantResponse({
      text: auditProse(assistantText),
      stage: inbound.state.stage,
      turnPlan: effectiveTurnPlan,
      allowedPriceLabels,
      responseContext: freeConversation ? "free_conversation" : undefined,
    });
    const inboundFallbackApplied = !initialInboundAudit.ok;
    if (inboundFallbackApplied) {
      assistantText = freeConversation ? freeCountUnavailable(lang) : sanitize(buildInboundSafeFallback(inbound.state.stage, lang, countExperience?.text ?? inbound.turnPlan.deterministicReply ?? businessMusicTurn?.text ?? customSongTurn?.text), lang);
    }
    const businessMusicAudit = businessMusicTurn
      ? auditBusinessMusicAssistantResponse({ text: assistantText, stage: businessMusicTurn.stage, previousAssistant: previousAssistantText(messages), conversationText: convo, expectedText: businessMusicTurn.text })
      : null;
    const businessMusicFallbackApplied = Boolean(businessMusicTurn && !businessMusicAudit?.ok);
    if (businessMusicFallbackApplied && businessMusicTurn) {
      assistantText = sanitize(businessMusicTurn.text, lang);
    }
    const customSongAudit = customSongTurn
      ? auditCustomSongAssistantResponse({ text: assistantText, stage: customSongTurn.stage, previousAssistant: previousAssistantText(messages) })
      : null;
    const customSongFallbackApplied = Boolean(customSongTurn && !customSongAudit?.ok);
    if (customSongFallbackApplied && customSongTurn) {
      assistantText = sanitize(customSongTurn.text, lang);
    }
    const initialMetalPrintAudit = metalSalesTurn
      ? auditMetalPrintAssistantResponse({ text: assistantText, turn: metalSalesTurn, recommendation: metalRecommendation })
      : null;
    const metalPrintFallbackApplied = Boolean(metalSalesTurn && !initialMetalPrintAudit?.ok);
    if (metalPrintFallbackApplied && metalSalesTurn) {
      assistantText = sanitize(metalSalesTurn.text, lang);
    }
    const finalMetalPrintAudit = metalSalesTurn
      ? auditMetalPrintAssistantResponse({ text: assistantText, turn: metalSalesTurn, recommendation: metalRecommendation })
      : null;
    const finalInboundAudit = auditInboundAssistantResponse({
      text: auditProse(assistantText),
      stage: inbound.state.stage,
      turnPlan: effectiveTurnPlan,
      allowedPriceLabels,
      responseContext: freeConversation ? "free_conversation" : undefined,
    });

    // 提示する CTA（商材ボタン）。care時は出さない。
    let cta: Cta | null = null;
    if (plan.mode !== "care" && plan.product && plan.product.ctaHref) {
      cta = {
        href: plan.product.ctaHref,
        label: productCtaLabelForLang(plan.product, lang),
        productId: plan.product.id,
      };
    }
    if (plan.mode !== "care" && plan.product?.id === "vip-metal-print" && selectedEdition) {
      cta = {
        href: `/metal-print/${selectedEdition.slug}`,
        label: lang === "ja" ? `${selectedEdition.title}の公開Dossierを見る` : `View the ${selectedEdition.title} public Dossier`,
        productId: plan.product.id,
      };
    }
    if (plan.mode !== "care" && musicAffinityTurn?.action === "dossier" && musicEntryWork) {
      const entryEditionId = getMetalPrintEditionIdForWork(String(musicEntryWork.id), String(musicEntryWork.title));
      const entryEdition = METAL_PRINT_VIP_EDITIONS.find((edition) => edition.id === entryEditionId);
      if (entryEdition) {
        cta = {
          href: `/metal-print/${entryEdition.slug}`,
          label: lang === "ja" ? `「${entryEdition.title}」の作品固有Dossierを見る` : `View the work-specific dossier for “${entryEdition.title}”`,
          productId: plan.product?.id ?? "vip-metal-print",
        };
      }
    }
    if (plan.mode !== "care" && businessMusicTurn?.cta) {
      cta = businessMusicTurn.cta;
    }
    if (plan.mode !== "care" && customSongTurn?.cta) {
      cta = customSongTurn.cta;
    }
    if (!effectiveTurnPlan.ctaAllowed) {
      cta = null;
    }

    const intent = distress
      ? "care"
      : musicAffinityTurn?.action === "dossier"
        ? "product"
      : musicAffinityTurn
        ? "conversation"
      : droneAffinityTurn
        ? "conversation"
      : nonSellingMetalTurn
        ? "conversation"
      : vipMetalPrint
        ? "product"
      : officeArt
        ? "business"
      : commercial === "business"
        ? "business"
        : commercial === "order"
          ? "order"
          : hintProduct
            ? "product"
            : plan.card
              ? "work"
              : "conversation";

    return res.status(200).json({
      ok: true,
      v: 3,
      assistantText,
      replySource: inboundFallbackApplied ? "fallback" : directText ? "curated" : llm.ok && llm.text ? "provider" : "fallback",
      experience: countExperience ? { kind: countExperience.kind, preferenceCount: countExperience.preferences.length, requestedExperience: true } : null,
      card: plan.card ?? null,
      cards: workAttribute?.cards ?? (plan.card ? [plan.card] : []),
      cta,
      persona: plan.persona.id,
      intent,
      productId: plan.product?.id ?? null,
      inboundStage: inbound.state.stage,
      inboundAudit: {
        ok: finalInboundAudit.ok,
        fallbackApplied: inboundFallbackApplied,
        initialFlags: initialInboundAudit.flags,
        finalFlags: finalInboundAudit.flags,
      },
      businessMusic: businessMusicTurn
        ? {
            stage: businessMusicTurn.stage,
            offerId: businessMusicTurn.offer.id,
            offerTitle: businessMusicTurn.offer.title,
            offerPrice: businessMusicTurn.offer.priceLabel,
            quoteSummary: buildBusinessMusicOrderBrief(businessMusicTurn.known, businessMusicTurn.offer),
            checkoutState: businessMusicTurn.offer.checkoutState,
            ctaAllowed: businessMusicTurn.ctaAllowed,
            negotiation: businessMusicTurn.negotiation
              ? {
                  authority: businessMusicTurn.negotiation.authority,
                  budgetYen: businessMusicTurn.negotiation.budgetYen,
                  alternativeOfferId: businessMusicTurn.negotiation.alternativeOfferId,
                  sameScopeDiscountApproved: false,
                }
              : null,
            auditOk: businessMusicAudit?.ok ?? false,
            auditFlags: businessMusicAudit?.flags ?? [],
            fallbackApplied: businessMusicFallbackApplied,
          }
        : null,
      workKnowledge: plan.workKnowledge
        ? { title: plan.workKnowledge.title, matchKind: plan.workKnowledge.matchKind }
        : null,
      workAttribute: plan.workAttribute ?? null,
      customSong: customSongTurn
        ? {
            stage: customSongTurn.stage,
            offerId: customSongTurn.offerId,
            offerTitle: customSongTurn.offerTitle,
            price: customSongTurn.priceLabel,
            quoteSummary: buildCustomSongOrderBrief(customSongTurn.known, customSongTurn.priceLabel),
            ctaAllowed: customSongTurn.ctaAllowed,
            auditOk: customSongAudit?.ok ?? false,
            auditFlags: customSongAudit?.flags ?? [],
            fallbackApplied: customSongFallbackApplied,
          }
        : null,
      interestBridge: interestBridge ? { id: interestBridge.id, action: interestBridge.action } : null,
      casualSalesEntry: casualSalesEntryTurn ? { branch: casualSalesEntryTurn.branch } : null,
      droneWork: droneAffinityTurn ? { action: droneAffinityTurn.action, work: droneAffinityTurn.work, saleStatus: "NOT_OFFERED" } : null,
      musicWork: musicAffinityTurn ? { action: musicAffinityTurn.action, work: musicEntryWork ? { id: String(musicEntryWork.id), title: String(musicEntryWork.title) } : null } : null,
      metalPrintRecommendation: metalRecommendation
        ? {
            editionId: metalRecommendation.edition.id,
            title: metalRecommendation.edition.title,
            source: metalRecommendation.source,
            score: metalRecommendation.score,
            reasons: metalRecommendation.reasons,
          }
        : null,
      metalPrint: metalSalesTurn
        ? {
            stage: metalSalesTurn.stage,
            readyForDossier: metalSalesTurn.readyForDossier,
            auditOk: finalMetalPrintAudit?.ok ?? false,
            auditFlags: finalMetalPrintAudit?.flags ?? [],
            initialAuditFlags: initialMetalPrintAudit?.flags ?? [],
            fallbackApplied: metalPrintFallbackApplied,
          }
        : null,
      corporate: plan.corporate
        ? {
            stage: plan.corporate.stage,
            nextFieldId: plan.corporate.nextField?.id ?? null,
            collected: plan.corporate.collectedFieldIds.length,
            missing: plan.corporate.missingRequiredIds.length,
            documentMode: plan.corporate.documentMode,
            taxMentionOwed: plan.corporate.taxMentionOwed,
            amountsRemoved: corporateAmountsRemoved,
          }
        : null,
      timeTone,
      provider: llm.provider,
      model: llm.model,
      providerTried: llm.tried ?? [],
      llmError: llm.error && /^[a-z0-9_]{1,80}$/.test(llm.error) ? llm.error : llm.error ? "provider_unavailable" : null,
      usage: llm.usage ?? null,
      ...(process.env.CHAT_EVAL_DEBUG === "1" ? { preAuditAssistantText } : {}),
      ...(process.env.CHAT_EVAL_DEBUG === "1"
        ? {
            salesRoutingDebug: {
              priorSalesSegment: priorSalesSegment ?? null,
              explicitBusinessSwitch,
              explicitCustomSwitch,
              rawBusinessMusicStage: rawBusinessMusicTurn?.stage ?? null,
              rawCustomSongStage: rawCustomSongTurn?.stage ?? null,
              selectedBusinessMusicStage: businessMusicTurn?.stage ?? null,
              selectedCustomSongStage: customSongTurn?.stage ?? null,
              distress,
            },
          }
        : {}),
      memory: {
        residue: assistantText.slice(0, 120),
        cardTitle: plan.card?.title ?? null,
        timestamp: new Date().toISOString(),
      },
      ...(process.env.NODE_ENV !== "production"
        ? { debug: { mode: plan.mode, persona: plan.persona.id, commercial, product: plan.product?.id ?? null, timeTone } }
        : {}),
      trace,
    });
  } catch (error) {
    const err = error as Error;
    return res.status(500).json({ ok: false, v: 3, error: "chat_unavailable", trace });
  }
}
