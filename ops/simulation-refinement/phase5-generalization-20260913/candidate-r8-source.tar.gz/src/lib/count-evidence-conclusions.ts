import {renderSourceScope} from './count-source-scope';
import {evidenceClaims,validateClaimSelection,type EvidenceRow,type EvidenceClaim,type ClaimPredicate} from './count-evidence-registry';
import {sourceMessages,type ProvenanceMessage} from './count-conversation-provenance';
import {abiKnowledgeReply} from './abi-public-knowledge';

export type WorkRequirement={predicate:ClaimPredicate;sourceId:string;quote:string;origin:'USER_STATED';lifecycle:'CURRENT_TURN'};
const relationPatterns: [ClaimPredicate,RegExp][] = [
  ['creator_belief_relation',/(?:作者|著者|伯爵|ABI|作り手).{0,24}(?:思想|哲学|信条)|(?:creator|author|artist|ABI|count)(?:['’]s)?\s+(?:own\s+)?(?:philosophy|beliefs)|philosophie.{0,20}(?:auteur|artiste)|filosof[ií]a.{0,20}(?:autor|artista)|Philosophie.{0,20}(?:Autor|Künstler)/i],
  ['perceptual_quality',/高音質|音質|録音の質|sound quality|audio quality|quality of (?:the )?(?:sound|recording)|qualité (?:sonore|audio)|calidad (?:de sonido|sonora)|Klangqualität/i],
  ['comparative_quality',/最高音質|音質.{0,12}(?:一番|最高)|(?:best|better|highest|clearest).{0,20}(?:sound|audio|recording)|(?:sound|audio).{0,20}(?:best|better|highest)|meilleur.{0,15}son|mejor.{0,15}sonido/i],
  ['verified_file_format',/\b(?:24[ -]?bit|96\s*kHz|lossless|WAV)\b|ロスレス|ビット深度/i],
];

/** Bounded high-risk relations are captured from current user text before search.
 * This recognizer does not claim general multilingual semantic entailment. */
export function currentWorkRequirements(messages:ProvenanceMessage[],type:string|null):WorkRequirement[] {
  const user=sourceMessages(messages).filter(s=>s.role==='user').at(-1);if(!user)return [];
  return relationPatterns.flatMap(([predicate,pattern])=>{
    if(predicate==='creator_belief_relation'&&type!=='book'&&!/本|書籍|\bbook\b|livre|libro|Buch/i.test(user.content))return [];
    const match=user.content.match(pattern);
    return match?[{predicate,sourceId:user.id,quote:match[0],origin:'USER_STATED' as const,lifecycle:'CURRENT_TURN' as const}]:[];
  });
}

/** No source currently establishes creator->book philosophy, perceptual ranking,
 * or full audio format for the catalog. Adding any requires an audited relation
 * source and capability; text similarity and owner curation cannot create it. */
export function satisfiesWorkRequirements(row:EvidenceRow,requirements:WorkRequirement[]) {
  const claims=evidenceClaims([row]);
  return requirements.every(r=>claims.some(c=>c.allowedPredicates.includes(r.predicate)));
}
export function validateConclusion(workId:string,predicate:ClaimPredicate,claimIds:string[],claims:EvidenceClaim[]) {
  return claimIds.length>0&&claimIds.every(id=>claims.some(c=>c.id===id&&c.workId===workId&&c.allowedPredicates.includes(predicate)));
}
export function relationGapReply(requirements:WorkRequirement[],lang:string) {
  const predicates=new Set(requirements.map(r=>r.predicate));
  if(predicates.has('creator_belief_relation'))return lang==='ja'
    ?'作者本人の哲学を説明する本として確認できる一冊は、今の資料では特定できません。'+abiKnowledgeReply('philosophy',lang,'哲学').text+' 本人の思想と、個々の本が扱う内容は分けてご案内します。'
    :'I cannot identify a book documented as explaining the creator’s own philosophy. '+abiKnowledgeReply('philosophy',lang,'philosophy').text+' Those beliefs do not establish what an individual book explains.';
  if(predicates.has('perceptual_quality')||predicates.has('comparative_quality'))return lang==='ja'
    ?'音質の良さや優劣を判断できる試聴・比較資料は確認できません。BPMや帯域などの数値だけで、高音質な曲として一作を選ぶことはできません。'
    :'I do not have listening or comparison evidence that establishes sound quality or a ranking. BPM and frequency measurements alone do not identify a higher-quality recording.';
  return lang==='ja'?'希望する音源形式を作品ごとに確かめられる資料がありません。登録ジャンルや曲名から形式を推測して選ぶことはできません。':'The available work sources do not verify the requested audio format. A genre label or title does not establish the file format.';
}

const labels:Record<string,Record<string,string>>={
  ja:{reported_metadata:'登録された制作メタデータ',documented_premise:'公開紹介文',visible_asset_detail:'画像の確認記録',scoped_machine_observation:'限定範囲の機械解析',edition_identity:'登録版情報',owner_selection:'本人による選出'},
  en:{reported_metadata:'Registered production metadata',documented_premise:'Published introduction',visible_asset_detail:'Image inspection',scoped_machine_observation:'Scoped machine analysis',edition_identity:'Registered edition',owner_selection:'Owner selection'},
};
const discoveryTopics:[string,number,RegExp][]=[
  ['ai',1,/\bAI\b|人工知能|intelligence artificielle/i],
  ['human',1,/人間|human|humain/i],
  ['labor',4,/仕事|労働|雇用|jobs?|labor|labour|employment|travail/i],
  ['creation',4,/創造|創作|作る意味|creativ|meaning of (?:making|art)/i],
  ['nature',2,/自然|nature|環境|environment/i],['travel',2,/旅|travel|voyage/i],
  ['universe',2,/宇宙|universe|cosmos/i],['satire',3,/風刺|satire/i],
  ['photography',1,/写真|photograph/i],['jazz',2,/ジャズ|jazz/i],
];
/** A discovery bridge needs both an actual user interest and a matching source
 * detail. Titles and assistant suggestions cannot supply either endpoint. */
export function discoveryBridge(row:EvidenceRow,messages:ProvenanceMessage[]) {
  const user=sourceMessages(messages).filter(s=>s.role==='user').at(-1);
  if(!user||!['public_editorial','content_derived','local_audio_machine_scoped'].includes(row.basis))return null;
  const matches=discoveryTopics.filter(([, ,topic])=>topic.test(user.content)&&topic.test(row.description));
  return matches.length?{origin:'USER_STATED' as const,sourceId:user.id,quote:user.content,workId:row.id,basis:row.basis,inference:'POSSIBLE_INTEREST_NOT_GUARANTEED',matchedTopics:matches.map(([name])=>name),score:matches.reduce((sum,[,weight])=>sum+weight,0),sourceClaims:evidenceClaims([row]).filter(c=>c.field==='description').map(c=>c.id)}:null;
}
type Selection={selectedIds:string[];evidence:{workId:string;claimIds:string[]}[];unverifiedDetails:string[];unknownConditions:string[]};
/** Render source excerpts, never a free-form conclusion with a valid ID attached.
 * Original source language is preserved. Translation remains a later evaluation
 * gate; an untranslated attributed excerpt is safer than fabricated entailment. */
export function renderRegisteredSelection(selection:Selection,rows:EvidenceRow[],lang:string,interestQuote='') {
  const claims=evidenceClaims(rows);
  if(!validateClaimSelection(selection.selectedIds,selection.evidence,claims))return null;
  if(!selection.selectedIds.length)return lang==='ja'?'検索した資料からは、今回の条件に合う作品を確認できませんでした。':'The retrieved sources do not establish a work matching this request.';
  const blocks=selection.selectedIds.map(id=>{
    const row=rows.find(r=>r.id===id)!;
    const refs=selection.evidence.filter(e=>e.workId===id).flatMap(e=>e.claimIds);
    const selected=claims.filter(c=>c.workId===id&&refs.includes(c.id));
    return `「${row.title}」\n`+selected.map(c=>`${(labels[lang]??labels.en)[c.allowedPredicates[0]]}: “${c.text.slice(0,360)}${c.text.length>360?'…':''}”`).join('\n');
  });
  const prefix=interestQuote?(lang==='ja'?`その関心から、一つ挙げるならこちらです。\n`:`Here is one possible starting point for that interest.\n`):'';
  const missing=selection.unverifiedDetails.length||selection.unknownConditions.length?(lang==='ja'?'\nご質問のうち、この引用の範囲を超える内容は確認できません。':'\nRequested details beyond these source excerpts remain unverified.'):'';
  const invitation=interestQuote?(lang==='ja'?`\nこの視点をもう少し見てみたいですか。`:'\nIs that a detail you would like to explore further?'):'';
  return prefix+blocks.join('\n\n')+missing+invitation;
}

/** Restored response metadata is a hint. Require an actual assistant message plus
 * current work/claim/text bindings before calling its basis an external source. */
export function priorAnswerSource(messages:ProvenanceMessage[],rows:EvidenceRow[],lang:string) {
  // Only the immediately preceding answer can supply an implicit "that source".
  // Older evidence stays available through explicit catalog retrieval; scanning
  // past a topic change can otherwise attach a book source to an audio question.
  const assistant=[...messages].reverse().find(m=>m.role==='assistant');
  return assistant?sourceForActualMessage(assistant,rows,lang):null;
}
function sourceForActualMessage(assistant:ProvenanceMessage,rows:EvidenceRow[],lang:string) {
  const stored=assistant?.conversationLedger?.replyEvidence;
  if(!stored||stored.assistantText!==assistant?.content||!stored.selectedIds.length)return null;
  const selectedRows=rows.filter(r=>stored.selectedIds.includes(r.id)),claims=evidenceClaims(selectedRows);
  if(!validateClaimSelection(stored.selectedIds,stored.evidence,claims))return null;
  const matched=claims.filter(c=>stored.evidence.some(e=>e.workId===c.workId&&e.claimIds.includes(c.id)));
  if(!matched.length)return null;
  const quoted=matched.every(c=>assistant.content.includes(c.text.slice(0,360)));
  const statements=stored.sourceStatements??[];
  const auditedParaphrase=statements.length>0&&statements.every(s=>assistant.content.includes(s.text)&&s.sourceIds.length>0&&s.sourceIds.every(id=>claims.some(c=>c.id===id)))&&matched.every(c=>statements.some(s=>s.sourceIds.includes(c.id)));
  if(!quoted&&!auditedParaphrase)return null;
  const bases=[...new Set(matched.map(c=>(labels[lang]??labels.en)[c.allowedPredicates[0]]))];
  return {origin:'EXTERNAL_FACT' as const,claimIds:matched.map(c=>c.id),basis:bases,sourcePaths:[...new Set(matched.map(c=>c.source).filter(p=>/^\/letters\/[a-z0-9-]+$/.test(p)))],fullTextVerified:false,
    sourceRecords:matched.map(c=>({workId:c.workId,claimId:c.id,...c.scope})),text:[...new Set(matched.map(c=>renderSourceScope(c.scope,lang,c.basis)))].join('\n')};
}
