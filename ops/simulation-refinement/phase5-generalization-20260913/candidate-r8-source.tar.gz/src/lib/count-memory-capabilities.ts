import type {ExpressionSource} from './count-grounded-expression';
import {sourceMessages,type ProvenanceMessage} from './count-conversation-provenance';

/** Source-level product capability, not an assertion about a live deletion. */
export function memoryCapabilitySources():ExpressionSource[] {
 return [{id:'memory:interface',origin:'EXTERNAL_FACT',capabilities:['interface_capability'],scope:'Reviewed /chat UI and history API implementation. Live storage, expiry, deletion and provider retention are not verified by this source.',text:'When the chat remembering option is enabled (default unless disabled in this browser), the UI attempts to save and restore this conversation using a browser-local identifier. The history API accepts up to 40 messages, including conversation-scoped preferences and sales state. Its configured expiry is 90 days after each successful update, not 90 days from the first message. The UI provides remembering on/off and a conversation delete control; these request deletion. The model cannot execute that deletion by conversational instruction, and neither this response nor the UI request verifies successful, complete deletion. The reviewed implementation does not establish a separate permanent personality profile, cross-device restoration, provider log retention or backup erasure. A next-day return may restore the saved conversation in the same browser when remembering remains enabled; this is conditional, not a promise. Sources: src/pages/chat.tsx and src/lib/chat-history.server.ts.'}];
}

/** A present utterance is not evidence that its alleged past event occurred. */
export function currentInstructionSource(messages:ProvenanceMessage[]):ExpressionSource[] {
 const latest=sourceMessages(messages).filter(s=>s.role==='user').at(-1);
 return latest?[{id:'conversation:current',origin:'EXTERNAL_FACT',capabilities:['current_request'],scope:'The current user message only. An allegation about earlier speech, buying, listening or deletion remains unverified. This source cannot prove such a past event.',text:JSON.stringify({currentUserMessage:latest.content,meaning:'Acknowledge the present correction or instruction. Do not quote it as an earlier memory or infer that any data was deleted.'})}]:[];
}
