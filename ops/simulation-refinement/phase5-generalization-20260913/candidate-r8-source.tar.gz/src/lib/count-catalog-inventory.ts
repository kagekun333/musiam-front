import type {CatalogWork} from './mergeWorksCatalog';
import {evidenceClaims,type EvidenceRow} from './count-evidence-registry';
import {workExpressionSources,type ExpressionSource} from './count-grounded-expression';

/** Global inventory is independent of retrieved candidates and selected cards. */
export function catalogInventorySources(works:CatalogWork[],rows:EvidenceRow[]):ExpressionSource[] {
 const count=(type:string)=>works.filter(w=>w.type===type).length;
 const music=count('music'),book=count('book'),image=count('image'),total=works.length;
 const limited=rows.filter(r=>r.type==='music'&&r.basis==='local_audio_machine_scoped').length;
 const metadata=rows.filter(r=>r.type==='music'&&r.basis==='metadata_only').length;
 const unknown=rows.filter(r=>r.type==='music'&&r.basis==='unknown').length;
 const textByLanguage:Record<string,string>={
  ja:`公開カタログ全${total}作の内訳は、音楽${music}作・書籍${book}作・写真${image}作です。音楽の限定機械解析は${limited}作で、残る${music-limited}作はその解析対象外です。これは全曲の内容理解や再生確認の件数ではありません。`,
  en:`The catalog contains ${total} works: ${music} music releases, ${book} books and ${image} photographs. ${limited} music releases have limited machine analysis; the remaining ${music-limited} do not have that analysis. These are not counts of whole-recording understanding or verified playback.`,
  fr:`Le catalogue compte ${total} œuvres : ${music} sorties musicales, ${book} livres et ${image} photographies. ${limited} sorties musicales ont une analyse automatique limitée ; les ${music-limited} autres n’en ont pas. Ce n’est pas une preuve de compréhension intégrale ni de lecture vérifiée.`,
  de:`Der Katalog enthält ${total} Werke: ${music} Musikveröffentlichungen, ${book} Bücher und ${image} Fotografien. Für ${limited} Musikveröffentlichungen liegt eine begrenzte maschinelle Analyse vor, für die übrigen ${music-limited} nicht. Das belegt weder vollständiges Inhaltsverständnis noch geprüfte Wiedergabe.`,
  es:`El catálogo contiene ${total} obras: ${music} publicaciones musicales, ${book} libros y ${image} fotografías. ${limited} publicaciones musicales tienen un análisis automático limitado; las otras ${music-limited} no. Esto no demuestra comprensión íntegra ni reproducción verificada.`,
  ar:`يضم الكتالوج ${total} عملًا: ${music} إصدارًا موسيقيًا و${book} كتابًا و${image} صورة. يتوفر تحليل آلي محدود لـ${limited} إصدارات موسيقية، ولا يتوفر هذا التحليل للإصدارات الـ${music-limited} المتبقية. وهذه ليست أعدادًا لفهم التسجيل الكامل أو لتشغيله المؤكد.`
 };
 return [{id:'inventory:counts',origin:'CATALOG_FACT',capabilities:['work_identity'],scope:'Entire current deduplicated catalog. Never substitute selected/retrieved row count for total. Music release records are not a total count of individual tracks.',text:JSON.stringify({totalWorks:total,musicReleases:music,books:book,photographs:image,musicLimitedMachineAnalysis:limited,musicNotInLimitedAnalysis:music-limited,musicMetadataOnly:metadata,musicUnknown:unknown,selectedSubsetIsNotWholeCatalog:true}),fixedStatement:{predicate:'work_identity',textByLanguage}},
 {id:'inventory:interface',origin:'EXTERNAL_FACT',capabilities:['interface_capability'],scope:'Current exhibition implementation; not an assertion of third-party playback, complete preview coverage or deployment success.',text:'The exhibition interface at /exhibition implements title/tag text search, media-type filtering and exact tag filtering. The chat page at /chat has an actual language selector with ja, en, fr, es, de, ar; Arabic is labelled العربية. The chat language setting is not proof that every external page or every catalog source has an Arabic translation. No physical premises, shelf map, lending stock, copy-condition history or in-person viewing service is established by these online records. Genre tags that exist on records can be used as tags; this is not a full listening-based genre taxonomy. Music cards provide registered external listening links such as Spotify and Apple Music where present. A link or stored preview observation does not establish every complete track is playable, current provider availability, ownership or purchase fulfillment. Source: /exhibition.'}];
}

/** Recorded visual details for a general photograph-content overview, never metadata-only rows. */
export function catalogContentOverviewSources(rows:EvidenceRow[]):ExpressionSource[] {
 return workExpressionSources(evidenceClaims(rows
  .filter(row=>row.type==='image'&&row.basis==='content_derived'))
  .filter(claim=>claim.field==='description'));
}

/** Catalog identity is available even when content evidence is incomplete. */
export function catalogIdentitySource(works:CatalogWork[]):ExpressionSource {
 return {id:'inventory:identity',origin:'CATALOG_FACT',capabilities:['work_identity'],scope:'Current loaded and deduplicated work catalog. Registered identity is not listening, reading, current external availability, ownership or a verified plot.',text:JSON.stringify({source:'Merged public work catalog, deduplicated by registered identity',identityFields:['stable work ID','canonical title','media type'],method:'A work exists in this catalog when its stable record is present in the current loaded catalog. Title/ID/media identity and content evidence are separate. A short introduction cannot establish a whole plot or ending; a title does not establish contents. Canonical titles remain exact; a requested translation must be explicitly labelled as a translation and retain the original title, never asserted as another registered title.',sample:works.slice(0,2).map(w=>({id:String(w.id),title:w.title,type:w.type}))})};
}
