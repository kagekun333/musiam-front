# Stage Gates (Do not edit before Discovery)

- Step-A レポート `.musiam/reports/step-A.md` が存在し、私の承認コメントがあるまで **プロジェクトの編集を禁止**。
- Discovery専用タスクでは Read-only ツールのみ使用。write_to_file はレポ生成の1回に限る。
- Step-A 承認後に Step 1 へ進む。各ステップの出口でレポを `.musiam/reports/step-*.md` に保存して停止。
