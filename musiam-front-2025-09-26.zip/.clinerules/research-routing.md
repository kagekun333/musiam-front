# Research Routing (Cline Project Rule)

- ライブラリ・仕様・相場などの **調査** は、まず **MCP: tavily-search** を使う。
- 結果は **出典URL** を明記し、要点を箇条書きで要約する。
- UI/挙動の確認は **Remote Browser** を使用し、完了後は必ずクローズ。
- Tavilyに障害がある場合のみ代替（serpapiなど）を使い、その旨をレポートに記録。
