import type { ConversationLedger } from "./count-conversation-provenance";
import { Redis } from "@upstash/redis";

export type StoredChatMessage = {
  role: "user" | "assistant";
  content: string;
  persona?: "count" | "duke";
  salesStopped?: boolean;
  conversationLedger?: ConversationLedger;
  salesSegment?: "business_music" | "custom_song" | "other";
  salesStage?: string;
  valueAngle?: "experience" | "use" | "format" | "entry" | "gift";
};

export type StoredChatContext = {
  source: string;
  medium: string;
  campaign: string;
  content: string;
  intent?: string;
  workId?: string;
  workTitle?: string;
  salesStage: "conversation" | "work_interest" | "product_interest" | "consultation";
};

export type StoredChatHistory = {
  version: 1;
  conversationId: string;
  lang: string;
  messages: StoredChatMessage[];
  context?: StoredChatContext;
  createdAt: string;
  updatedAt: string;
  expiresAt: string;
};

export const CHAT_HISTORY_TTL_SECONDS = 60 * 60 * 24 * 90;
export const CHAT_HISTORY_MAX_MESSAGES = 40;

let redis: Redis | null = null;

function getRedis() {
  const url = process.env.UPSTASH_REDIS_REST_URL ?? process.env.KV_REST_API_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN ?? process.env.KV_REST_API_TOKEN;
  if (!url || !token) throw new Error("Upstash Redis is not configured");
  if (!redis) redis = new Redis({ url, token });
  return redis;
}

function key(conversationId: string) {
  return `chat-history:v1:${conversationId}`;
}

const CHAT_HISTORY_INDEX_KEY = "chat-history:v1:index";

export async function readChatHistory(conversationId: string) {
  return getRedis().get<StoredChatHistory>(key(conversationId));
}

export async function writeChatHistory(input: {
  conversationId: string;
  lang: string;
  messages: StoredChatMessage[];
  context?: StoredChatContext;
}) {
  const existing = await readChatHistory(input.conversationId);
  const now = new Date();
  const record: StoredChatHistory = {
    version: 1,
    conversationId: input.conversationId,
    lang: input.lang,
    messages: input.messages.slice(-CHAT_HISTORY_MAX_MESSAGES),
    context: input.context ?? existing?.context,
    createdAt: existing?.createdAt ?? now.toISOString(),
    updatedAt: now.toISOString(),
    expiresAt: new Date(now.getTime() + CHAT_HISTORY_TTL_SECONDS * 1000).toISOString(),
  };
  await getRedis().set(key(input.conversationId), record, { ex: CHAT_HISTORY_TTL_SECONDS });
  await getRedis().sadd(CHAT_HISTORY_INDEX_KEY, input.conversationId);
  return record;
}

export async function deleteChatHistory(conversationId: string) {
  await getRedis().del(key(conversationId));
  await getRedis().srem(CHAT_HISTORY_INDEX_KEY, conversationId);
}

export async function listChatHistories(limit = 200) {
  const client = getRedis();
  const ids = (await client.smembers(CHAT_HISTORY_INDEX_KEY)).slice(0, Math.max(1, Math.min(limit, 500)));
  const histories: StoredChatHistory[] = [];
  const expired: string[] = [];
  for (const conversationId of ids) {
    const history = await client.get<StoredChatHistory>(key(conversationId));
    if (history) histories.push(history);
    else expired.push(conversationId);
  }
  if (expired.length) await client.srem(CHAT_HISTORY_INDEX_KEY, ...expired);
  return histories.sort((a, b) => Date.parse(b.updatedAt) - Date.parse(a.updatedAt));
}
