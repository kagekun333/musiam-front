import {sourceScope,type SourceScope} from './count-source-scope';
import { createHash } from "node:crypto";
export type EvidenceRow={id:string;title:string;type:string;basis:string;source:string;description:string;edition:string;metadata:string[];vocals:string;ownerCuration?:string;scope?:SourceScope};
export type ClaimPredicate="reported_metadata"|"documented_premise"|"visible_asset_detail"|"scoped_machine_observation"|"edition_identity"|"owner_selection"|"creator_belief_relation"|"verified_file_format"|"perceptual_quality"|"comparative_quality";
export type EvidenceClaim={id:string;sourceId:string;workId:string;field:"description"|"edition"|"ownerCuration";text:string;basis:string;source:string;allowedPredicates:ClaimPredicate[];scope:SourceScope};
const digest=(s:string)=>createHash("sha256").update(s).digest("hex").slice(0,20);
/** A capability describes the evidence type, not what a model hopes it proves. */
export function sourceCapabilities(row:EvidenceRow,field:EvidenceClaim["field"]):ClaimPredicate[] {
  if(field==="ownerCuration")return ["owner_selection"];
  if(field==="edition")return ["edition_identity"];
  if(row.basis==="public_editorial")return ["documented_premise"];
  if(row.basis==="content_derived"&&row.type==="image")return ["visible_asset_detail"];
  if(row.basis==="local_audio_machine_scoped")return ["scoped_machine_observation"];
  if(row.basis==="metadata_only")return ["reported_metadata"];
  return [];
}
export function evidenceClaims(rows:EvidenceRow[]) {
  return rows.flatMap(row=>(["description","edition","ownerCuration"] as const).flatMap(field=>{
    const text=row[field]??"",allowedPredicates=sourceCapabilities(row,field);if(!text.trim()||!allowedPredicates.length)return[];
    const source=field==="ownerCuration"?"owner-confirmation:2026-09-12":row.source;
    const sourceId=`src_${digest(source)}`;
    const scope:SourceScope=field==="ownerCuration"?{sourceLocator:source,extent:"Owner's selection only; not objective quality, meaning or rank.",confidence:"SOURCE_RECORDED"}:field==="edition"?{sourceLocator:source,extent:"Registered edition identity only; not a content or listening assessment.",confidence:"SOURCE_RECORDED"}:row.scope??sourceScope(row.id,row.basis,source);
    return [{id:`claim_${digest(row.id+":"+field+":"+row.basis+":"+allowedPredicates.join(",")+":"+sourceId+":"+text)}`,sourceId,workId:row.id,field,text,basis:field==="ownerCuration"?"owner_selected":row.basis,source,allowedPredicates,scope}];
  }));
}
export function validateClaimSelection(selectedIds:string[],references:{workId:string;claimIds:string[]}[],claims:EvidenceClaim[]) {
  return references.every(ref=>ref.claimIds.length>0&&ref.claimIds.every(id=>claims.some(c=>c.id===id&&c.workId===ref.workId)))&&selectedIds.every(id=>references.some(ref=>ref.workId===id&&ref.claimIds.length>0));
}
