// src/pages/oracle.tsx
export default function OraclePage() {
  return (
    <main className="p-8">
      <h1 className="text-xl font-semibold">Oracle</h1>
      <p className="text-gray-600 mt-2">占いページのプロトタイプ。</p>
    </main>
  );
}
