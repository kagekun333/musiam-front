import { abiKnowledgeReply, classifyAbiSelfQuery } from "./abi-public-knowledge";
import { buildCatalogConversation } from "./count-catalog-conversation";
import { buildValueSalesTurn, type ValueAngle } from "./count-value-sales";
import { analyzeInboundConversation } from "./inbound-conversation-policy";
import { loadMergedWorksServer } from "./loadMergedWorksServer";
import { chat } from "./llm-router";
import { buildSemanticCountTurn } from "./count-semantic-turn";

type Message={role:string;content:string;valueAngle?:ValueAngle;salesStopped?:boolean};
export function preservesVerifiedTranslation(source:string,translated:string,lang:string) {
  const numbers=(s:string)=>(s.match(/\d+(?:[,.]\d+)*/g)??[]).map(v=>v.replace(/,/g,"")).sort().join("|");
  const titles=[...source.matchAll(/[“「]([^”」]+)[”」]/g)].map(m=>m[1]);
  if(numbers(source)!==numbers(translated)||/https?:\/\//i.test(translated))return false;
  if(!["ABI Hakusyaku","MUSIAM",...titles].every(n=>!source.includes(n)||translated.includes(n)))return false;
  const negative:Record<string,RegExp>={fr:/\b(?:pas|non|sans|inconnu|aucun|distinct)\b/i,de:/\b(?:nicht|kein\w*|unbekannt|ohne|getrennt|anders|verschieden)\b/i,es:/\b(?:no|sin|desconocid\w*|distint\w*|separad\w*)\b/i,ar:/لا|ليس|غير|لم|منفصل/};
  const hold:Record<string,RegExp>={fr:/suspend|attente|indisponible/i,de:/ausgesetzt|pausiert|nicht verfügbar/i,es:/suspend|espera|no disponible/i,ar:/معلق|متوقف|غير متاح/};
  if(/do not have|cannot|not verified|unverified|not an independent|not that person|separate from|not a bundle/i.test(source)&&!negative[lang]?.test(translated))return false;
  if(/on hold/i.test(source)&&!hold[lang]?.test(translated))return false;
  if(/AI Count/.test(source)&&!/AI Count|\b(?:IA|AI)\b|intelligence artificielle|künstliche Intelligenz|inteligencia artificial|ذكاء اصطناعي/i.test(translated))return false;
  return true;
}
async function localizeVerifiedReply<T extends {assistantText:string;provider:string;model:string;replySource:string}>(reply:T,lang:string):Promise<T> {
  if(lang==="ja"||lang==="en")return reply;
  const names:Record<string,string>={fr:"French",de:"German",es:"Spanish",ar:"Arabic"};
  if(!names[lang])return reply;
  const result=await chat({purpose:"quality",system:`Translate the supplied verified MUSIAM answer into ${names[lang]}. Output only the translated answer. Preserve all proper names, work titles and numerical values exactly. Add no facts, offers, questions, URLs, promises or interpretation. Distinguish ABI Hakusyaku the creator from the AI Count.`,messages:[{role:"user",content:reply.assistantText}],maxTokens:700,trace:"verified-public-answer-translation"});
  if(result.ok&&preservesVerifiedTranslation(reply.assistantText,result.text,lang))return {...reply,assistantText:result.text,provider:result.provider,model:result.model,replySource:"provider"};
  const intro:Record<string,string>={fr:"La traduction est indisponible. Voici la réponse vérifiée en anglais :",de:"Die Übersetzung ist gerade nicht verfügbar. Hier ist die geprüfte Antwort auf Englisch:",es:"La traducción no está disponible. Esta es la respuesta verificada en inglés:",ar:"الترجمة غير متاحة الآن. إليك الإجابة المتحققة باللغة الإنجليزية:"};
  return {...reply,assistantText:intro[lang]+"\n"+reply.assistantText,replySource:"fallback"};
}
export async function buildCountRefinementTurn(messages:Message[],lang:string) {
  return buildSemanticCountTurn(messages,lang);
}
/** Kept for deterministic regression comparison; not the active semantic path. */
export async function buildLegacyRefinementTurn(messages:Message[],lang:string) {
  const userMessages=messages.filter(m=>m.role==="user").map(m=>m.content);
  const state=analyzeInboundConversation(userMessages);
  if(state.hasDistress)return null;
  const latest=userMessages.at(-1)??"";
  const responseLang=lang==="ja"&&/^[\x00-\x7F\s’“”]+$/.test(latest)&&/[a-z]{3}/i.test(latest)?"en":lang;
  const topic=classifyAbiSelfQuery(messages);
  const base={knowledgeRoute:null as string|null,ok:true,v:3,provider:"none",model:"",replySource:"curated",persona:"count",intent:"conversation",card:null,cards:[],cta:null,inboundStage:state.stage,inboundAudit:{ok:true,fallbackApplied:false,initialFlags:[],finalFlags:[]}};
  if(topic){
    const self=abiKnowledgeReply(topic,responseLang);
    return localizeVerifiedReply({...base,assistantText:self.text,knowledgeRoute:"abi_self",selfKnowledge:{...self,text:undefined}},responseLang);
  }
  const value=buildValueSalesTurn(messages,responseLang);
  if(value){
    const experience=value.valueAngle==="experience"?buildCatalogConversation(await loadMergedWorksServer(),[{role:"user",content:"川や街の空撮写真を一枚紹介して"}],responseLang):null;
    const text=value.text+(experience?.card?(responseLang==="ja"?` 下の「${experience.card.title}」から眺められます。`:` You can explore “${experience.card.title}” below.`):"");
    return localizeVerifiedReply({...base,assistantText:text,card:experience?.card??null,cards:experience?.cards??[],cta:value.cta,valueAngle:value.valueAngle,valueSales:value.valueSales,intent:value.intent,productId:"productId" in value.valueSales?value.valueSales.productId:null},responseLang);
  }
  const catalog=buildCatalogConversation(await loadMergedWorksServer(),messages,responseLang,state.hasOptOut);
  if(catalog)return localizeVerifiedReply({...base,...catalog,assistantText:catalog.text,text:undefined,intent:catalog.card?"work":"conversation"},responseLang);
  return null;
}
