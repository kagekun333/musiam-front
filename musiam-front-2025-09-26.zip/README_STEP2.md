# Step 2: Handoff 自動生成（musiam-front）

## 使い方（Windows）
1) このフォルダをプロジェクト直下に上書きコピー（`.musiam/` と `.vscode/` が追加されます）。
2) VS Code → `Tasks: Run Task` → **Generate Handoff (Windows)** を実行。
3) `.musiam/HANDOFF.md` が生成されるので、中身を確認 → **Copy Handoff to Clipboard (Windows)** を実行してGPTに貼る。

> `gh`（GitHub CLI）が入っていなくても動きます（入っているとOpen Issues/PRの一覧が入ります）。
