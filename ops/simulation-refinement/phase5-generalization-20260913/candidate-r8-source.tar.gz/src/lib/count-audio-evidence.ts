import observations from '../data/music-machine-observations.json';
import {sourceScope} from './count-source-scope';
import type {ExpressionSource} from './count-grounded-expression';
import type {CatalogWork} from './mergeWorksCatalog';

/** Source identity and current catalog membership are separate relationships.
 * A removed/unbound catalog row does not erase a recorded analysis, but that
 * record cannot create a selectable work or prove current availability. */
export function audioEvidenceSources(works:CatalogWork[]):ExpressionSource[] {
 return observations.items.map(record=>{
  const work=works.find(w=>String(w.id)===record.workId&&w.title===record.title);
  const provenance=sourceScope(record.workId,'local_audio_machine_scoped',record.sourceLocator);
  const asr='asrObservation' in record?record.asrObservation:null;
  return {id:`audio:${record.workId}`,origin:'EXTERNAL_FACT' as const,capabilities:['scoped_machine_observation'],scope:provenance.extent,provenance,
   ...(work?{workId:record.workId}:{}),
   text:JSON.stringify({recordedTitle:record.title,sourceLocator:record.sourceLocator,sourceKind:record.sourceKind,analysisDurationSeconds:record.analysisDurationSeconds,recordedPublicIdentityMatch:record.identityMatchScope,publicTrackBinding:record.publicTrackBinding,confidence:record.confidence,measurements:record.measurements,asrObservation:asr,currentCatalogWorkId:work?record.workId:null,currentCatalogBinding:work?'BOUND':'UNBOUND: no current catalog membership or recommendation claim',humanListeningReview:false,fullRemoteMasterMatch:false,wholeRecordingVocalAbsenceVerified:false,sourceHref:record.sourceHref})};
 });
}
