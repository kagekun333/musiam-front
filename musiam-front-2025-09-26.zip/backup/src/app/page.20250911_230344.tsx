// app/page.tsx
import GatesLanding from "@/components/GatesLanding";

export default function Page() {
  return <GatesLanding />;
}
