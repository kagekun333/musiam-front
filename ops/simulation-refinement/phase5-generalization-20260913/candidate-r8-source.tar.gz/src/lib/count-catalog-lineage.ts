import lineage from '../data/catalog-metadata-lineage.json';
import {getPublicLinksForCard} from './work-links';
import type {CatalogWork} from './mergeWorksCatalog';

/** Restore only recorded production metadata to the same public album entity.
 * Search URLs and similar titles never establish identity. Audio claims do not
 * travel through this bridge; their exact source/scope binding is separate. */
export function linkedCatalogMetadata(work:CatalogWork) {
  const row=lineage.items.find(r=>r.canonicalWorkId===String(work.id)&&r.title===work.title);
  if(!row||row.basis!=='metadata_only'||work.type!=='music')return null;
  if(!/^https:\/\/open\.spotify\.com\/album\/[A-Za-z0-9]+$/.test(row.publicIdentityHref))return null;
  if(!getPublicLinksForCard(work).some(link=>link.url===row.publicIdentityHref))return null;
  return row;
}
