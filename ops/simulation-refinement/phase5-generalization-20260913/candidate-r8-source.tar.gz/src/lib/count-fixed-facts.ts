/** Relational identity facts use an authoritative, directional rendering. The
 * surrounding interpretation remains free; subject and object cannot swap. */
export function identityRelation(fact:{id?:string;assertion:string;text:string;en:string|null}) {
  if(fact.id==='host'&&fact.assertion==='application_role')return {kind:'guide_role' as const,subject:'AI Count',object:'AI Count',texts:{
    ja:fact.text,
    en:'You are speaking with MUSIAM’s AI Count, a software guide. It is not the human creator or a real aristocratic title.',
    fr:'Vous parlez au comte IA de MUSIAM, un guide logiciel. Ce n’est ni le créateur humain ni un titre de noblesse réel.',
    de:'Sie sprechen mit dem KI-Grafen von MUSIAM, einem Software-Guide. Er ist weder der menschliche Schöpfer noch ein wirklicher Adelstitel.',
    es:'Hablas con el Conde IA de MUSIAM, un guía de software. No es el creador humano ni un título nobiliario real.',
    ar:'أنت تتحدث مع كونت MUSIAM بالذكاء الاصطناعي، وهو دليل برمجي، وليس المبدع البشري أو لقب نبالة حقيقي.'
  } as Record<string,string>};
  if(fact.assertion!=='owner_confirmed_identity'||!fact.en)return undefined;
  const match=fact.en.match(/^(.+?) is an alias of (.+?)\./);
  if(!match)return undefined;
  const [,subject,object]=match;
  return {kind:'alias_of' as const,subject,object,texts:{
    ja:fact.text,en:fact.en,
    fr:`${subject} est le nom d’usage de ${object}. Dans les présentations courantes, le nom privilégié est ${subject}.`,
    de:`${subject} ist ein Künstlername von ${object}. Für gewöhnliche Vorstellungen wird ${subject} verwendet.`,
    es:`${subject} es un alias de ${object}. En las presentaciones habituales se prefiere ${subject}.`,
    ar:`${subject} هو اسم مستعار لـ ${object}. ويُفضّل استخدام ${subject} في التعريف المعتاد.`
  } as Record<string,string>};
}
