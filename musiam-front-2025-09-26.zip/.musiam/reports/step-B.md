# Step-B Report

## Created/Modified Files

* .musiam/spec/exhibition.page.json
* .musiam/spec/oracle.page.json
* .musiam/spec/count.page.json
* .musiam/spec/works.schema.json
* .musiam/spec/analytics.events.json
* public/works/works.json
* src/lib/spec.ts
* src/lib/loadWorks.ts
* src/lib/recommender.ts
* scripts/validate-works.mjs
* scripts/link-check.mjs
* .github/workflows/validate-works.yml
