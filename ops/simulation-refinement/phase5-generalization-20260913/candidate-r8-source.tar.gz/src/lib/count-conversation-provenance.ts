import { createHash } from "node:crypto";
import { z } from "zod";

export type Modality = "music" | "book" | "image";
export type ConstraintKind = "audio_vocals" | "audio_bass" | "audio_runtime" | "genre" | "language" | "visual_color" | "visual_subject" | "content" | "user_context" | "commerce";
export type ConstraintProposal = {kind:ConstraintKind;value:string;origin:"USER_STATED"|"INFERRED";sourceId:string;quote:string;hard:boolean;excluded:boolean;operation:"add"|"remove"};
export type ConstraintRecord = ConstraintProposal & {id:string;scope:"AUDIO"|"VISUAL"|"CONTENT"|"USER_CONTEXT"|"COMMERCE";verifiedSource:boolean;lifecycle?:"CURRENT_TURN"|"SESSION_MODALITY"};
export type WorkRejection={workId:string;sourceId:string;quote:string};
export type ReplyEvidence={sourceStatements?:{text:string;sourceIds:string[]}[];assistantText:string;selectedIds:string[];evidence:{workId:string;claimIds:string[]}[]};
export type ConversationLedger = {replyEvidence?:ReplyEvidence;rejections?:WorkRejection[];constraints:ConstraintRecord[];recommendedIds:string[];rejectedIds:string[]};
const workRejectionSchema=z.object({workId:z.string().max(200),sourceId:z.string().max(40),quote:z.string().max(300)});
export const conversationLedgerSchema=z.object({replyEvidence:z.object({sourceStatements:z.array(z.object({text:z.string().max(900),sourceIds:z.array(z.string().max(100)).max(6)})).max(7).optional(),assistantText:z.string().max(6000),selectedIds:z.array(z.string().max(200)).max(3),evidence:z.array(z.object({workId:z.string().max(200),claimIds:z.array(z.string().max(100)).max(4)})).max(6)}).optional(),rejections:z.array(workRejectionSchema).max(30).optional(),constraints:z.array(z.object({kind:z.enum(["audio_vocals","audio_bass","audio_runtime","genre","language","visual_color","visual_subject","content","user_context","commerce"]),value:z.string().max(300),origin:z.enum(["USER_STATED","INFERRED"]),sourceId:z.string().max(40),quote:z.string().max(300),hard:z.boolean(),excluded:z.boolean(),operation:z.enum(["add","remove"]),id:z.string().max(40),scope:z.enum(["AUDIO","VISUAL","CONTENT","USER_CONTEXT","COMMERCE"]),verifiedSource:z.boolean(),lifecycle:z.enum(["CURRENT_TURN","SESSION_MODALITY"]).optional()})).max(30),recommendedIds:z.array(z.string().max(200)).max(30),rejectedIds:z.array(z.string().max(200)).max(30)});
export type ProvenanceMessage = {role:string;content:string;conversationLedger?:ConversationLedger};
const hash=(s:string)=>createHash("sha256").update(s).digest("hex").slice(0,16);
export function sourceMessages(messages:ProvenanceMessage[]) {
  const occurrences=new Map<string,number>();
  return messages.map((m,i)=>{const key=m.role+":"+m.content,occurrence=(occurrences.get(key)??0)+1;occurrences.set(key,occurrence);return {id:`${m.role==="user"?"u":"a"}-${hash(key+":"+occurrence)}`,role:m.role,content:m.content,index:i};}).filter(m=>m.role==="user"||m.role==="assistant");
}
const terms:Record<string,RegExp>={sf:/\bSF\b|sci[ -]?fi|science[ -]?fiction|ciencia ficción|ciencia ficcion|近未来/i,classic:/古典|翻案|classi|klassik/i,fantasy:/fantas|ファンタジー/i,satire:/satir|風刺/i,jazz:/jazz|ジャズ/i,rock:/\brock\b|ロック/i,dance:/dance|danse|ダンス/i,latin:/latin|ラテン/i,ambient:/ambient|アンビエント/i,techno:/techno|テクノ/i,hiphop:/hip[ -]?hop|rap\b|ラップ|ヒップホップ/i,ja:/日本語|japanese|japonais|japonés/i,en:/英語|english|anglais|inglés/i,de:/ドイツ語|german|deutsch|allemand|alemán/i,fr:/フランス語|french|français|francés/i,es:/スペイン語|spanish|español|espagnol/i};
const audioWords=/vocals?|singing|lyrics?|voices?|chant|paroles|voix|voces|letra|gesang|stimmen|歌|声|ボーカル|音声|歌詞|صوت|غناء|instrumental|インスト/i;
function scope(kind:ConstraintKind):ConstraintRecord["scope"] {
  return kind.startsWith("audio_")?"AUDIO":kind.startsWith("visual_")?"VISUAL":kind==="user_context"?"USER_CONTEXT":kind==="commerce"?"COMMERCE":"CONTENT";
}
function explicitNegative(quote:string,term:RegExp) {
  const m=quote.match(term);if(!m)return false;
  const before=quote.slice(Math.max(0,(m.index??0)-35),m.index).trim(),after=quote.slice((m.index??0)+m[0].length).trim();
  return /(?:\bno|\bnot|without|avoid|exclude|excluding|sans|sin|kein(?:e|en)?|ohne|pas de)\s*(?:any\s*)?$/i.test(before)||/^(?:は|が|を|も)?(?:なし|不要|禁止|以外|じゃない|ではない|は避け|を避け|抜き)/.test(after);
}
export function constraintLifecycle(kind:ConstraintKind,quote:string):"CURRENT_TURN"|"SESSION_MODALITY" {
  if(/今回|今度|この(?:一曲|一冊|写真)|今は|this (?:time|one|turn)|for now|cette fois|esta vez|diesmal/i.test(quote))return "CURRENT_TURN";
  if(/いつも|今後|この会話|以後|always|from now|throughout|in this conversation|toujours|siempre|immer/i.test(quote))return "SESSION_MODALITY";
  if(["genre","language","visual_subject","visual_color"].includes(kind))return /好き|嫌い|苦手|好み|prefer|\blike\b|\blove\b|\bhate\b|dislike|j'aime|préfère|me gusta|prefiero|mag ich|bevorzuge/i.test(quote)?"SESSION_MODALITY":"CURRENT_TURN";
  return ["content","user_context","audio_runtime"].includes(kind)?"CURRENT_TURN":"SESSION_MODALITY";
}
export function applicableConstraint(c:ConstraintRecord,modality:Modality|null) {
  if(c.scope==="USER_CONTEXT"||c.scope==="COMMERCE")return false;
  if(c.scope==="AUDIO")return modality==="music";
  if(c.scope==="VISUAL")return modality==="image";
  if(c.kind==="genre"&&["jazz","rock","dance","latin","ambient","techno","hiphop"].includes(c.value))return modality==="music";
  if(c.kind==="language")return modality!=="image";
  return true;
}
export function resolveConstraintLedger(messages:ProvenanceMessage[],proposals:ConstraintProposal[],modality:Modality|null,rejectionProposals:WorkRejection[]=[]) {
  const sources=sourceMessages(messages),latest=sources.filter(s=>s.role==="user").at(-1);
  const previous=[...messages].reverse().find(m=>m.role==="assistant"&&m.conversationLedger)?.conversationLedger;
  const records=new Map<string,ConstraintRecord>(),rejected:{proposal:ConstraintProposal;reason:string}[]=[];
  const sourceFor=(p:ConstraintProposal)=>sources.find(s=>s.id===p.sourceId&&s.role==="user"&&p.quote.trim().length>1&&s.content.includes(p.quote));
  for(const input of [...(previous?.constraints??[]).map(c=>({...c,operation:"add" as const})),...proposals]){
    const p={...input};
    const lifecycle=constraintLifecycle(p.kind,p.quote);
    if(lifecycle==="CURRENT_TURN"&&p.sourceId!==latest?.id)continue;
    if(!sourceFor(p)){rejected.push({proposal:p,reason:"NOT_AN_ACTUAL_USER_QUOTE"});continue;}
    const concept=terms[p.value];
    if((p.kind==="genre"||p.kind==="language")&&(!concept||!concept.test(p.quote))){rejected.push({proposal:p,reason:"CANONICAL_CONCEPT_NOT_USER_STATED"});continue;}
    if(p.kind==="audio_vocals"&&!audioWords.test(p.quote)){rejected.push({proposal:p,reason:"VOCAL_CONCEPT_NOT_STATED"});continue;}
    if(p.kind==="audio_vocals"&&!['absent','background','allowed'].includes(p.value)){rejected.push({proposal:p,reason:"UNKNOWN_AUDIO_REQUIREMENT"});continue;}
    if(p.kind==="audio_vocals"&&p.value==="absent"&&/(?:foreground|front|前に|目立|控え|background|discret|hintergrund|protagonismo)/i.test(p.quote)){p.value="background";}
    if(p.kind==="audio_vocals"&&p.value==="absent"&&!/(?:without|\bno\b|sans|sin|ohne|kein|なし|無し|ない|不要|禁止|抜き|instrumental|インスト|لا|بدون)/i.test(p.quote)){rejected.push({proposal:p,reason:"ABSENCE_NOT_EXPLICIT"});continue;}
    if(concept&&p.excluded&&!explicitNegative(p.quote,concept)){rejected.push({proposal:p,reason:"EXCLUSION_NOT_EXPLICIT"});continue;}
    const id=hash(p.kind+":"+(["genre","language","content"].includes(p.kind)?p.value:"singleton"));
    if(p.operation==="remove"){
      if(p.sourceId===latest?.id&&/(?:forget|drop|remove|no longer|instead|cancel|any .*fine|oubl|plus besoin|retir|quita|ya no|vergiss|nicht mehr|解除|撤回|忘れ|取り消|変更)/i.test(p.quote))records.delete(id);
      else rejected.push({proposal:p,reason:"REMOVAL_NOT_EXPLICIT_CURRENT_USER"});
      continue;
    }
    // Inferences remain suggestions. Free-form hard conditions are the visitor's
    // verbatim words, never a model-written expansion or translation of them.
    const value=p.kind==="content"&&p.origin==="USER_STATED"?p.quote:p.value;
    records.set(id,{...p,value,excluded:concept?explicitNegative(sourceFor(p)!.content,concept):p.excluded,hard:p.hard&&p.origin==="USER_STATED",id,scope:scope(p.kind),verifiedSource:true,lifecycle});
  }
  const constraints=[...records.values()].slice(-30),active=constraints.filter(c=>applicableConstraint(c,modality));
  const rejections=[...(previous?.rejections??[]),...rejectionProposals].filter(r=>previous?.recommendedIds.includes(r.workId)&&sources.some(source=>source.role==="user"&&source.id===r.sourceId&&r.quote.trim().length>1&&source.content.includes(r.quote))&&/(?:not (?:for me|that|this)|don['’]?t (?:like|want)|dislike|reject|rather (?:not|another)|no more|pas (?:pour moi|celui|celle)|n['’].*pas|no (?:me|quiero|esa|ese)|nicht|別の|違う|いらない|好みでは|避け|ほかの|他の)/i.test(r.quote));
  const uniqueRejections=[...new Map(rejections.map(r=>[r.workId,r])).values()].slice(-30);
  return {ledger:{constraints,recommendedIds:previous?.recommendedIds??[],rejectedIds:uniqueRejections.map(r=>r.workId),rejections:uniqueRejections} as ConversationLedger,active,inactive:constraints.filter(c=>!applicableConstraint(c,modality)),rejected};
}
export function effectiveCatalogConstraints(state:ReturnType<typeof resolveConstraintLedger>) {
  return {noVocals:state.active.some(c=>c.kind==="audio_vocals"&&c.value==="absent"&&c.origin==="USER_STATED"),conditions:state.active.filter(c=>(c.kind==="genre"||c.kind==="language")&&c.hard).map(c=>({id:c.value,group:c.kind as "genre"|"language",excluded:c.excluded})),otherRequired:state.active.filter(c=>c.hard&&(!["genre","language","audio_vocals"].includes(c.kind)||c.kind==="audio_vocals"&&c.value==="background")).map(c=>c.kind==="content"?c.quote:c.quote),softPreferences:state.active.filter(c=>!c.hard).map(c=>({value:c.value,origin:c.origin,quote:c.quote})),userContext:state.ledger.constraints.filter(c=>c.scope==="USER_CONTEXT"||c.scope==="COMMERCE").map(c=>c.quote)};
}
export type MemoryRequest={mode:"none"|"recall"|"attribution";subject:"user"|"assistant";claim:string;sourceIds:string[]};
const literal=(s:string)=>s.normalize("NFKC").toLowerCase().replace(/[\s\p{P}]/gu,"");
export function renderMemoryReply(request:MemoryRequest,messages:ProvenanceMessage[],lang:string) {
  if(request.mode==="none")return null;
  const prior=sourceMessages(messages).slice(0,-1),refs=prior.filter(s=>s.role===request.subject&&request.sourceIds.includes(s.id));
  const matches=request.mode==="recall"?refs:refs.filter(s=>request.claim.trim().length>1&&literal(s.content).includes(literal(request.claim)));
  const alternative=request.mode==="attribution"&&!matches.length&&request.claim.trim().length>1?prior.filter(s=>s.role!==request.subject&&literal(s.content).includes(literal(request.claim))).slice(-1):[];
  const quotes=matches.slice(-3).map(s=>`“${s.content}”`).join("\n");
  const who=request.subject==="user"?"you":"I";
  const none:Record<string,string>={ja:"その発言は、この会話の該当する発言履歴では確認できません。そう言ったことを前提にはしません。",en:`I cannot verify that ${who} said that in the actual conversation history. I will not treat that attribution as established.`,fr:"Je ne retrouve pas cette déclaration dans les messages concernés de cette conversation. Je ne la traiterai pas comme un fait établi.",de:"Diese Aussage kann ich in den entsprechenden Nachrichten dieses Gesprächs nicht belegen. Ich werde diese Zuschreibung nicht als Tatsache behandeln.",es:"No puedo verificar esa afirmación en los mensajes correspondientes de esta conversación. No la trataré como un hecho establecido.",ar:"لا أجد ما يثبت هذه العبارة في الرسائل المعنية من هذه المحادثة، ولن أتعامل مع نسبتها إلى صاحبها كحقيقة مؤكدة."};
  const labels:Record<string,string>={ja:request.subject==="user"?"この会話の履歴にある、あなたの実際の発言です。":"この会話の履歴にある、私の実際の発言です。",en:`The source is this conversation history. The actual ${request.subject} message is:`,fr:`La source est l’historique de cette conversation. Voici le message réel (${request.subject}) :`,de:`Die Quelle ist der Verlauf dieses Gesprächs. Die tatsächliche Nachricht (${request.subject}) lautet:`,es:`La fuente es el historial de esta conversación. Este es el mensaje real (${request.subject}):`,ar:"المصدر هو سجل هذه المحادثة. هذه هي الرسالة الفعلية:"};
  const correction=alternative.length?"\n"+(lang==="ja"?"別の話者による実際の発言: ":"Actual message from the other speaker: ")+alternative.map(s=>`[${s.role}] “${s.content}”`).join("\n"):"";
  return {answer:(matches.length?`${labels[lang]??labels.en}\n${quotes}`:none[lang]??none.en)+correction,alternativeProvenance:alternative.map(s=>({sourceId:s.id,origin:s.role==="user"?"USER_STATED":"ASSISTANT_STATED",quote:s.content})),provenance:matches.map(s=>({sourceId:s.id,origin:s.role==="user"?"USER_STATED":"ASSISTANT_STATED",quote:s.content})),status:matches.length?"VERIFIED_LITERAL_SOURCE":"NOT_VERIFIED"};
}
